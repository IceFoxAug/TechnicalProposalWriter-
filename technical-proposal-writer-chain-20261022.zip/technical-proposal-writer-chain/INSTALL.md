# 安装说明

本包是技术标书写作 skill（`technical-proposal-writer`）及其依赖的离线副本。以下步骤在一台全新的 Claude Code 机器上执行，约 3–5 分钟。

---

## 一、前置条件

| 项 | 要求 | 说明 |
|---|---|---|
| Claude Code | 任意近期版本 | 需要支持 skills 目录与 `Skill` 工具 |
| Python | 3.9 及以上 | 开发验证环境为 3.11；`python --version` 确认 |
| pip | 随 Python 安装 | 用于安装第三方包 |
| 磁盘空间 | 约 250 KB（不含 Python 包） | |
| 网络 | 仅安装依赖时需要 | 写作过程不联网（"自己找文献"规则例外） |
| Tesseract-OCR | 可选 | 仅扫描版 PDF 需要 OCR |

---

## 二、关键目录约定

安装目标为用户技能目录：

- Windows：`%USERPROFILE%\.claude\skills\`（如 `C:\Users\张三\.claude\skills\`）
- macOS / Linux：`~/.claude/skills/`

**必须保持包内的相对层级**，原因有两个：

1. `docx-secure-renderer/renderer.py` 用 `Path(__file__).resolve().parent.parent` 向上查找 `omml_helper.py`，因此 `writer.py`、`omml_helper.py` 必须在 `skills/` **根目录**，不能放进子文件夹。
2. `omml_helper.py` 会去 `skills/patent-writer/` 导入增强公式解析器 `parse_formula_enhanced`。

安装完成后的目录应如下（只列新增部分）：

```
%USERPROFILE%\.claude\skills\
├── writer.py
├── omml_helper.py
├── technical-proposal-writer\SKILL.md
├── pdf-reader\SKILL.md
├── omml-formula-writer\SKILL.md
├── docx-secure-renderer\{SKILL.md, renderer.py, md_parser.py}
└── patent-writer\formula_parser.py      ← 只放这一个文件，不要覆盖已有 patent-writer
```

---

## 三、安装步骤

### 步骤 1：解压

把 zip 解压到任意临时目录（解压后得到 `technical-proposal-writer-chain\` 文件夹）。

> 如果使用 Windows 资源管理器解压后中文内容出现乱码，请改用 7-Zip 或 PowerShell 的 `Expand-Archive`，包内文件均为 UTF-8 编码。

### 步骤 2：安装技能文件

**方式 A：一键脚本（推荐）**

```powershell
cd <解压目录>\technical-proposal-writer-chain

# 先演练：只打印计划，不改动磁盘
.\install.ps1

# 确认无误后执行；同名旧 skill 会先备份为 <名称>.bak-<时间戳>
.\install.ps1 -Apply
```

若 PowerShell 禁止运行脚本，改用：

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 -Apply
```

脚本行为：

- 把 `skills\` 下的 9 个文件复制到 `%USERPROFILE%\.claude\skills\`
- 已存在同名文件/目录时，先 `Move-Item` 到 `.bak-<时间戳>`，不做静默覆盖
- 复制后把副本中的 `C:\Users\Andre Fan\.claude\skills` 替换为本机实际路径（**原件不受影响**）

**方式 B：手动复制**

1. 若 `%USERPROFILE%\.claude\skills\` 不存在，先创建。
2. 复制 `skills\writer.py`、`skills\omml_helper.py` 到该目录根下。
3. 复制 `skills\technical-proposal-writer\`、`skills\pdf-reader\`、`skills\omml-formula-writer\`、`skills\docx-secure-renderer\` 四个文件夹进去。
4. 若已有 `patent-writer\` 文件夹，只把 `formula_parser.py` 放进去（**不要替换整个目录**）；没有则新建。
5. 按第四节改写硬编码路径。

### 步骤 3：安装 Python 依赖

```powershell
pip install -r requirements.txt
```

必需与可选的划分：

| 类别 | 包 | 缺失后果 |
|---|---|---|
| 必需 | `python-docx`、`lxml`、`Pillow` | 无法读写 docx / 无法构建 OMML / renderer 导入失败 |
| 建议 | `pdfplumber`、`PyMuPDF`、`pypdf` | PDF 提取策略链退化为单一策略甚至失败 |
| 可选 | `pytesseract` + `pdf2image` | 扫描版 PDF 无法 OCR |
| 可选 | `latex2mathml` | 公式转换第二策略失效，复杂 LaTeX 可能降级为图片 |
| 可选 | `matplotlib` | 公式图片化渲染不可用 |

如使用 OCR，还要安装 Tesseract 本体，并确认 `pdf-reader\SKILL.md` 第 65、83 行的 `tesseract_cmd` 指向本机路径：

```python
pytesseract.pytesseract.tesseract_cmd = r'D:\Program Files\Tesseract-OCR\tesseract.exe'
```

### 步骤 4：改写硬编码路径（非原机器必做）

`install.ps1 -Apply` 已自动替换 `C:\Users\Andre Fan` 前缀。手动安装或路径结构不同，按表处理：

| 文件:行 | 原值 | 改为 |
|---|---|---|
| `technical-proposal-writer\SKILL.md:287,291,451` | `C:\Users\Andre Fan\.claude\skills` | 本机技能根目录 |
| `omml-formula-writer\SKILL.md:29,35,49,50,362,365` | 同上 | 同上 |
| `docx-secure-renderer\SKILL.md:129,158` | 同上 + `\docx-secure-renderer` | 同上 |
| `patent-writer\formula_parser.py:13` | `C:\Users\Andre Fan\.claude\skills` | 同上 |
| `omml_helper.py:790` | `C:\Users\Andre Fan\.claude\skills\patent-writer` | 建议 `str(Path(__file__).resolve().parent / "patent-writer")` |
| `docx-secure-renderer\renderer.py:57` | `WORKING_DIR = Path(r"C:\Users\Andre Fan")` | `Path.home()` |
| `docx-secure-renderer\renderer.py:53-55` | `D:/shared/templates/*.docx` | 本机模板库（未随包提供；也可调用时直接传模板路径绕过） |
| `pdf-reader\SKILL.md:65,83` | `D:\Program Files\Tesseract-OCR\...` | 本机 Tesseract 路径 |

批量替换命令（PowerShell）：

```powershell
$root = "$env:USERPROFILE\.claude\skills"
Get-ChildItem $root -Recurse -Include *.md,*.py | ForEach-Object {
    $text = Get-Content $_.FullName -Raw
    if ($text.Contains('C:\Users\Andre Fan\.claude\skills')) {
        $text.Replace('C:\Users\Andre Fan\.claude\skills', $root) |
            Set-Content $_.FullName -NoNewline -Encoding UTF8
    }
}
```

### 步骤 5：注册到 CLAUDE.md

在全局 `~/.claude/CLAUDE.md`（或项目级 `CLAUDE.md`）中加入：

```markdown
### technical-proposal-writer
技术标书写作专家。根据标书模板 (docx) 和原始文献 (PDF) 自动生成研究现状、研究内容等章节。
依赖 pdf-reader skill。

触发条件：用户需要撰写或修改技术标书时使用，涉及 docx 模板解析、PDF 原始文献内容提取、标书章节生成等场景。

**任何时候**用户要求撰写技术标书（"写标书""撰写标书第X节""修改标书"等），第一步必须调用
`Skill(skill="technical-proposal-writer", args="...")`，不得自行用 pdfplumber / python-docx 绕过实现。

核心规则：
- 写作前先确认章节类型（研究现状：高密度引用、无公式图片；研究内容：无引用、需 OMML 公式与图片）
- 正文不出现研究者姓名和年份
- 图片除推知内容外只能来自原始文献，禁止自绘
- 公式以 OMML 格式独立成段并附"式中："解释
```

### 步骤 6：自检

```powershell
cd <解压目录>\technical-proposal-writer-chain
python check_env.py
```

预期结尾输出：

```
结论
  必需项全部通过。可选依赖缺失不影响核心写作链路（会降级）。
```

自检覆盖四项：9 个文件完整性、Python 依赖可导入性、包内硬编码路径清单、四个关键模块接口（`TechnicalProposalWriter`、`add_omath_paragraph`、`add_inline_math_paragraph`、`validate_docx`、`parse_formula_enhanced`）。

---

## 四、升级与卸载

- **升级**：重新运行 `install.ps1 -Apply`。脚本会先把旧文件移到 `.bak-<时间戳>`，需要时手动恢复。
- **卸载**：删除复制进去的 9 个文件/目录；**不要**删除整个 `patent-writer\` 目录（可能包含其他 skill 的文件）。
- **回滚**：把 `%USERPROFILE%\.claude\skills\<名称>.bak-<时间戳>` 改回原名即可。

---

## 五、安装故障排查

| 现象 | 原因 | 处理 |
|---|---|---|
| `ModuleNotFoundError: No module named 'docx'` | 未装 python-docx | `pip install python-docx` |
| `ModuleNotFoundError: No module named 'omml_helper'` | 两个 .py 没放在 skills 根目录，或 Python 未把该目录加入 path | 移到根目录；脚本中 `sys.path.insert(0, <skills根>)` |
| `ModuleNotFoundError: No module named 'md_parser'` | 用 `python renderer.py` 直接跑而工作目录不对 | 从 `docx-secure-renderer` 目录运行，或用 `sys.path` 指定 |
| renderer 自检显示 `D:/shared/templates` ❌ | 模板库未随包提供 | 调用时直接传 `.docx` 路径，不用模板别名 |
| OCR 报 `tesseract is not installed` | 未装 Tesseract 或路径不符 | 安装后改 `pdf-reader\SKILL.md` 的 `tesseract_cmd` |
| `pip install` 很慢或失败 | 网络 | 换镜像：`pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple` |
| Linux/macOS 上路径报错 | 包内为 Windows 路径示例 | 按第四节替换为本机路径，分隔符改为 `/` |
