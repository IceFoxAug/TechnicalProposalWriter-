# technical-proposal-writer 技能包

技术标书写作 skill 及其全部依赖的离线打包，可迁移到其他 Claude Code 环境。

| 项 | 值 |
|---|---|
| 打包时间 | 2026-10-22 |
| 来源机器 | Windows 11，Python 3.11 |
| 来源路径 | `C:\Users\Andre Fan\.claude\skills\` |
| 包内文件 | 9 个源文件 + 4 份文档 + 依赖清单 + 安装/自检脚本 |

## 文档导航

| 文档 | 用途 |
|---|---|
| `INSTALL.md` | **安装说明**：前置条件、一键/手动安装、依赖安装、路径改写、CLAUDE.md 注册、自检、故障排查 |
| `USAGE.md` | **使用说明**：材料准备、发起写作、两类章节差异、执行流程、验收清单、常见问题 |
| `README.md` | 本文档：包内容清单、依赖关系、硬编码路径总表 |
| `check_env.py` | 环境自检脚本（只读） |
| `install.ps1` | 安装脚本（默认演练，`-Apply` 才落盘） |

---

## 一、包含内容

```
technical-proposal-writer-chain/
├── README.md                    本文档（内容清单与依赖关系）
├── INSTALL.md                   安装说明
├── USAGE.md                     使用说明
├── requirements.txt             第三方 Python 依赖
├── check_env.py                 环境与文件完整性自检（只读）
├── install.ps1                  安装脚本（默认演练，-Apply 才落盘）
└── skills/
    ├── writer.py                TechnicalProposalWriter 框架（模板解析 + 内容注入）
    ├── omml_helper.py           OMML 公式引擎（行间公式 / 内联数学符号）
    ├── technical-proposal-writer/
    │   └── SKILL.md             主 skill：写作规范与执行协议
    ├── pdf-reader/
    │   └── SKILL.md             PDF 文本提取策略链（pdfplumber→PyMuPDF→PyPDF2→OCR）
    ├── omml-formula-writer/
    │   └── SKILL.md             OMML 公式语法参考与三线表/插图规范
    ├── docx-secure-renderer/
    │   ├── SKILL.md             docx 渲染/校验 skill
    │   ├── renderer.py          文档结构校验（validate_docx）与 Markdown 渲染
    │   └── md_parser.py         渲染管线使用的 Markdown 解析器
    └── patent-writer/
        └── formula_parser.py    增强公式解析器（parse_formula_enhanced）
```

### 为什么包含这些文件

| 文件 | 被谁需要 | 缺省的后果 |
|---|---|---|
| `writer.py` | technical-proposal-writer 步骤 3/4/6 | 无法解析模板、无法注入章节内容 |
| `omml_helper.py` | technical-proposal-writer、docx-secure-renderer（通过 `parent.parent` 导入） | 公式退化为纯文本或图片，结构校验能力下降 |
| `pdf-reader/SKILL.md` | technical-proposal-writer 步骤 1 用 `Skill(skill="pdf-reader")` 调用 | 无法按协议提取 PDF，只能自行实现解析 |
| `omml-formula-writer/SKILL.md` | 公式编写规范参考 | 公式语法、三线表、插图参数失去统一口径 |
| `docx-secure-renderer/*` | technical-proposal-writer 生成后强制调用 `validate_docx()` | 跳过结构校验，XML 损坏无法发现 |
| `patent-writer/formula_parser.py` | `omml_helper.py:790` 尝试导入 `parse_formula_enhanced` | 静默回退到基础 `parse_formula`，复杂公式解析能力降级 |

不包含：`__pycache__`、`.bak` 文件、用户项目模板与原始文献（每个项目不同，由用户提供）。

---

## 二、安装

### 方式 A：一键安装（PowerShell）

```powershell
# 先演练，看清会改动什么（默认不落盘）
.\install.ps1

# 确认后执行；已存在的同名 skill 会先备份为 <名称>.bak-<时间戳>
.\install.ps1 -Apply
```

### 方式 B：手动复制

把 `skills/` 下的内容按原样复制到用户技能目录，**必须保持相对层级**：

- Windows：`%USERPROFILE%\.claude\skills\`
- macOS / Linux：`~/.claude/skills/`

关键点：`writer.py` 与 `omml_helper.py` 必须位于 `skills/` 根目录，`docx-secure-renderer/renderer.py` 通过 `Path(__file__).resolve().parent.parent` 找到它们。

---

## 三、第三方 Python 依赖

```powershell
pip install -r requirements.txt
```

| 包 | 必需性 | 用途 |
|---|---|---|
| `python-docx` | 必需 | 读取模板、写入 OMML 公式与段落 |
| `lxml` | 必需 | OMML / OOXML 元素构建 |
| `Pillow` | 必需 | renderer.py 图片处理（无条件导入） |
| `pdfplumber` | 建议 | PDF 文本提取策略 1 |
| `PyMuPDF`（`fitz`） | 建议 | 策略 2，图片/文本提取 |
| `pypdf` | 建议 | 策略 3 兜底 |
| `pytesseract` + `pdf2image` | 可选 | 扫描件 OCR |
| `latex2mathml` | 可选 | 公式转换第二策略 |
| `matplotlib` | 可选 | 公式降级为图片时使用 |

外部系统依赖（仅扫描版 PDF 需要）：Tesseract-OCR。若安装路径不是 `D:\Program Files\Tesseract-OCR\tesseract.exe`，需修改 `pdf-reader/SKILL.md` 中的 `tesseract_cmd`。

---

## 四、换机后需要修改的硬编码路径

包内保留原始文件内容，**未做路径改写**，以保证与源环境一致。迁移到不同用户名或路径时，按下表调整：

| 文件:行 | 原值 | 建议改为 |
|---|---|---|
| `skills/technical-proposal-writer/SKILL.md:287,291,451` | `C:\Users\Andre Fan\.claude\skills` | 实际技能根目录 |
| `skills/omml-formula-writer/SKILL.md:29,35,49-50,362-365` | 同上 | 同上 |
| `skills/docx-secure-renderer/SKILL.md:129,158` | `C:\Users\Andre Fan\.claude\skills\docx-secure-renderer` | 同上 |
| `skills/omml_helper.py:790` | `C:\Users\Andre Fan\.claude\skills\patent-writer` | 改为 `Path(__file__).parent / "patent-writer"` |
| `skills/docx-secure-renderer/renderer.py:57` | `WORKING_DIR = Path(r"C:\Users\Andre Fan")` | `Path.home()` |
| `skills/docx-secure-renderer/renderer.py:53-55` | `D:/shared/templates/*.docx` | 本机模板实际位置（该模板库未随包提供，按模板路径调用即可） |
| `skills/pdf-reader/SKILL.md:65,83` | `D:\Program Files\Tesseract-OCR\tesseract.exe` | 本机 Tesseract 路径 |

PowerShell 批量替换示例（先确认目标用户名）：

```powershell
$root = "$env:USERPROFILE\.claude\skills"
Get-ChildItem $root -Recurse -Include *.md,*.py |
  ForEach-Object {
    (Get-Content $_.FullName -Raw) -replace [regex]::Escape('C:\Users\Andre Fan\.claude\skills'), $root |
      Set-Content $_.FullName -NoNewline
  }
```

> `install.ps1 -Apply` 已对复制后的副本自动做上述 `C:\Users\Andre Fan` 前缀替换。

---

## 五、注册到 CLAUDE.md

在全局或项目 `CLAUDE.md` 中加入以下片段，让主模型知道何时调用：

```markdown
### technical-proposal-writer
技术标书写作专家。根据标书模板 (docx) 和原始文献 (PDF) 自动生成研究现状、研究内容等章节。
依赖 pdf-reader skill。

触发条件：用户需要撰写或修改技术标书时使用，涉及 docx 模板解析、PDF 原始文献内容提取、标书章节生成等场景。

**任何时候**用户要求撰写技术标书（"写标书""撰写标书第X节""修改标书"等），第一步必须调用
`Skill(skill="technical-proposal-writer", args="...")`，不得自行用 pdfplumber/python-docx 实现。
```

---

## 六、自检

```powershell
python check_env.py
```

脚本只读，输出四部分：文件清单完整性、Python 依赖可达性、包内硬编码路径提示、关键模块导入与函数存在性。

预期结果：9 个文件全部存在；`python-docx` / `lxml` / `Pillow` 可导入；`writer.TechnicalProposalWriter`、`omml_helper.add_omath_paragraph`、`omml_helper.add_inline_math_paragraph`、`renderer.validate_docx` 均可加载。

---

## 七、使用流程（解包后）

1. 将模板 `.docx` 与原始文献 `.pdf` 放入同一工作目录（原始文献建议置于 `lib/`）。
2. 在 Claude Code 中发起：`写标书，模板是 template.docx，原始文献在 lib/ 下`。
3. skill 会先询问：章节属于「研究现状」还是「研究内容」、预期篇幅。
4. 流程：pdf-reader 解析 PDF → 提取模板 Word 注释 → writer.parse_template → 撰写 → 引用去重 →
   注入 OMML 公式 → 保存 → `validate_docx()` 结构校验。
