# -*- coding: utf-8 -*-
"""
OMML Formula Helper — docx-secure-renderer 的内部公式转换模块。

职责：接受 LaTeX 字符串，返回 OMML XML 片段（lxml Element）。
定位：不直接对最终用户或其他 Skill 开放，仅响应 docx-secure-renderer 的调用。
其他写作 Skill（patent-writer, technical-proposal-writer）通过 docx-secure-renderer
间接使用本模块，无需知晓内部调用细节——它们只需在 Markdown 中写 LaTeX 即可。

核心能力：
  - parse_formula(text) → token list：扁平公式文本 → OMML token 流
  - OMMLEq.build_formula(tokens) → OMML XML：token → 完整 m:oMath 元素
  - convert_latex_to_omml(latex) → OMML XML：LaTeX 字符串 → OMML（新增统一入口）
  - convert_latex_batch(latex_list) → OMML 列表：批量转换接口

回退链：OMMLEq 原生解析 → latex2mathml → MathML→OMML → 失败返回 None
"""
from docx.oxml.ns import qn, nsmap
from docx.shared import Pt, Cm, Inches, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from lxml import etree
import re
import sys
import xml.etree.ElementTree as ET

MATH_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
MATHML_NS = 'http://www.w3.org/1998/Math/MathML'

def _m(tag):
    """Create an OMML element in the math namespace."""
    return etree.SubElement(etree.Element('dummy'), qn('m:'+tag))
    # Simpler: just build from string

class OMMLEq:
    """Build OMML equations programmatically."""

    def __init__(self):
        self.ns = MATH_NS

    def _elem(self, tag, parent=None):
        el = etree.Element(qn('m:'+tag))
        if parent is not None:
            parent.append(el)
        return el

    def _r(self, parent, text, style='normal'):
        """Add a math run with text."""
        mr = self._elem('r', parent)
        # Add w:rPr for font styling (Cambria Math for equation text)
        w_rPr = etree.SubElement(mr, qn('w:rPr'))
        w_rFonts = etree.SubElement(w_rPr, qn('w:rFonts'))
        w_rFonts.set(qn('w:ascii'), 'Cambria Math')
        w_rFonts.set(qn('w:hAnsi'), 'Cambria Math')
        if style == 'italic':
            nor = self._elem('nor', mr)
            self._elem('rPr', nor)
        mt = self._elem('t', mr)
        mt.text = text
        mt.set(qn('xml:space'), 'preserve')
        return mr

    def _sub(self, parent, base, sub):
        """Add subscript: base_sub. Recursively parses base and sub for inner operators."""
        ss = self._elem('sSub', parent)
        e_base = self._elem('e', ss)
        self._render_base(e_base, base)
        e_sub = self._elem('sub', ss)
        self._render_base(e_sub, sub)  # parse nested _/^ in subscript text
        return ss

    def _sup(self, parent, base, sup):
        """Add superscript: base^sup. Recursively parses base and sup for inner operators."""
        ss = self._elem('sSup', parent)
        e_base = self._elem('e', ss)
        self._render_base(e_base, base)
        e_sup = self._elem('sup', ss)
        self._render_base(e_sup, sup)  # parse nested _/^ in superscript text
        return ss

    def _subsup(self, parent, base, sub, sup):
        """Add combined sub+superscript. Recursively parses all text for inner operators."""
        ss2 = self._elem('sSubSup', parent)
        e_base = self._elem('e', ss2)
        self._render_base(e_base, base)
        e_sub = self._elem('sub', ss2)
        self._render_base(e_sub, sub)  # parse nested _/^ in subscript text
        e_sup = self._elem('sup', ss2)
        self._render_base(e_sup, sup)  # parse nested _/^ in superscript text
        return ss2

    def _rad(self, parent, body, degree=None):
        """Add radical (square root or nth root): √body or ∛body"""
        rad = self._elem('rad', parent)
        if degree is not None:
            deg = self._elem('deg', rad)
            self._r(deg, str(degree))
        e = self._elem('e', rad)
        self._r(e, body)
        return rad

    def _frac(self, parent, num, den):
        f = self._elem('f', parent)
        fn = self._elem('num', f)
        self._r(fn, num)
        fd = self._elem('den', f)
        self._r(fd, den)
        return f

    def _group(self, parent, items):
        """Add a group of math elements (for complex expressions)."""
        d = self._elem('d', parent)
        for item in items:
            if isinstance(item, str):
                self._r(d, item)
            elif isinstance(item, tuple):
                kind = item[0]
                if kind == 'sub':
                    self._sub(d, item[1], item[2])
                elif kind == 'sup':
                    self._sup(d, item[1], item[2])
                elif kind == 'subsup':
                    self._subsup(d, item[1], item[2], item[3])
                elif kind == 'frac':
                    self._frac(d, item[1], item[2])
                elif kind == 'bracket':
                    self._r(d, '(')
                    self._group(d, item[1])
                    self._r(d, ')')
        return d

    def _render_base(self, parent, text):
        """Render text with recursive parsing of sub/sup operators.

        Handles: _{...}, ^{...}, _letter, ^letter, and promotions.
        Fixes Phase 1's bracket passthrough where operators inside (...)
        are not tokenized and remain as literal _/^ chars.
        """
        if '_' not in text and '^' not in text:
            self._r(parent, text, 'italic')
            return

        i = 0
        buf = []
        while i < len(text):
            c = text[i]
            # ── _{...} brace subscript ──
            if c == '_' and i+1 < len(text) and text[i+1] == '{':
                base_ident = self._pop_last_ident(buf)
                if buf:
                    self._r(parent, ''.join(buf), 'italic')
                    buf.clear()
                depth = 1
                k = i + 2
                while k < len(text) and depth > 0:
                    if text[k] == '{': depth += 1
                    elif text[k] == '}': depth -= 1
                    k += 1
                sub = text[i+2:k-1]
                # Check ^{...} after _{...} → promote to subsup
                if k < len(text) and text[k] == '^':
                    if k+1 < len(text) and text[k+1] == '{':
                        depth2, k2 = 1, k+2
                        while k2 < len(text) and depth2 > 0:
                            if text[k2] == '{': depth2 += 1
                            elif text[k2] == '}': depth2 -= 1
                            k2 += 1
                        sup = text[k+2:k2-1]
                        self._subsup(parent, base_ident, sub, sup)
                        i = k2; continue
                    elif k+1 < len(text) and text[k+1].isalnum():
                        j = k+1
                        while j < len(text) and text[j].isalnum(): j += 1
                        sup = text[k+1:j]
                        self._subsup(parent, base_ident, sub, sup)
                        i = j; continue
                self._sub(parent, base_ident, sub)
                i = k; continue
            # ── _letter simple subscript (no braces) ──
            elif c == '_' and i+1 < len(text) and text[i+1].isalnum():
                base_ident = self._pop_last_ident(buf)
                if buf:
                    self._r(parent, ''.join(buf), 'italic')
                    buf.clear()
                j = i+1
                while j < len(text) and text[j].isalnum(): j += 1
                sub = text[i+1:j]
                # Check ^letter after → promote
                if j < len(text) and text[j] == '^':
                    if j+1 < len(text) and text[j+1] == '{':
                        depth2, j2 = 1, j+2
                        while j2 < len(text) and depth2 > 0:
                            if text[j2] == '{': depth2 += 1
                            elif text[j2] == '}': depth2 -= 1
                            j2 += 1
                        sup = text[j+2:j2-1]
                        self._subsup(parent, base_ident, sub, sup)
                        i = j2; continue
                    elif j+1 < len(text) and text[j+1].isalnum():
                        jj = j+1
                        while jj < len(text) and text[jj].isalnum(): jj += 1
                        sup = text[j+1:jj]
                        self._subsup(parent, base_ident, sub, sup)
                        i = jj; continue
                self._sub(parent, base_ident, sub)
                i = j; continue
            # ── ^{...} brace superscript (no preceding _) ──
            elif c == '^' and i+1 < len(text) and text[i+1] == '{':
                base_ident = self._pop_last_ident(buf)
                if buf:
                    self._r(parent, ''.join(buf), 'italic')
                    buf.clear()
                depth = 1
                k = i + 2
                while k < len(text) and depth > 0:
                    if text[k] == '{': depth += 1
                    elif text[k] == '}': depth -= 1
                    k += 1
                sup = text[i+2:k-1]
                self._sup(parent, base_ident, sup)
                i = k; continue
            # ── ^letter simple superscript (no braces) ──
            elif c == '^' and i+1 < len(text) and text[i+1].isalnum():
                base_ident = self._pop_last_ident(buf)
                if buf:
                    self._r(parent, ''.join(buf), 'italic')
                    buf.clear()
                j = i+1
                while j < len(text) and text[j].isalnum(): j += 1
                sup = text[i+1:j]
                self._sup(parent, base_ident, sup)
                i = j; continue
            else:
                buf.append(c)
                i += 1

        if buf:
            self._r(parent, ''.join(buf), 'italic')

    def _pop_last_ident(self, buf):
        """Pop trailing alphanumeric/Greek identifier chars from a char buffer list.
        Returns the popped identifier string. Buffer is modified in-place.
        e.g. buf=['(','Σ'] → returns 'Σ', buf becomes ['(']
        """
        ident_chars = []
        while buf and re.match(r'[a-zA-Z0-9Α-ω]', buf[-1]):
            ident_chars.insert(0, buf.pop())
        return ''.join(ident_chars) or 'x'

    def build_formula(self, tokens):
        """Build OMML from token list.
        tokens: list of strings (plain text) or tuples (type, args...)
        Types: 'sub', 'sup', 'subsup', 'frac', 'bracket', 'greek', 'italic'
        """
        omath = etree.Element(qn('m:oMath'))
        for token in tokens:
            if isinstance(token, str):
                self._r(omath, token)
            elif isinstance(token, tuple):
                kind = token[0]
                if kind == 'sub':
                    self._sub(omath, token[1], token[2])
                elif kind == 'sup':
                    self._sup(omath, token[1], token[2])
                elif kind == 'subsup':
                    self._subsup(omath, token[1], token[2], token[3])
                elif kind == 'frac':
                    self._frac(omath, token[1], token[2])
                elif kind == 'd':
                    self._group(omath, token[1])
                elif kind == 'rad':
                    if len(token) >= 3:
                        self._rad(omath, token[1], token[2])
                    else:
                        self._rad(omath, token[1])
                elif kind == 'nary':
                    sub = token[2] if len(token) > 2 else ''
                    sup = token[3] if len(token) > 3 else ''
                    self._nary(omath, token[1], sub, sup)
        return omath

    def _nary(self, parent, char, sub_text, sup_text):
        """Add n-ary operator (sum/product) with sub/sup limits.
        Recursively parses limit text for nested sub/sup operators."""
        nary = self._elem('nary', parent)
        naryPr = self._elem('naryPr', nary)
        chr_e = self._elem('chr', naryPr)
        chr_e.set(qn('m:val'), char)
        grow = self._elem('grow', naryPr)
        grow.set(qn('m:val'), '1')
        if sub_text:
            sub_e = self._elem('sub', nary)
            self._render_base(sub_e, sub_text)  # parse nested _/^ in limit text
        if sup_text:
            sup_e = self._elem('sup', nary)
            self._render_base(sup_e, sup_text)  # parse nested _/^ in limit text
        # e (base) — nary operator itself, already in chr
        e = self._elem('e', nary)
        self._r(e, char)
        return nary


# ---- Simplified formula text parser ----
def parse_formula(text):
    """Parse a simplified formula text into OMML tokens.
    Handles: subscripts like C_inv, P_rated; superscripts like r^2;
    Greek letters like η, ω, σ, ξ, α, Δ, Σ;
    fractions via /; brackets via [] or ()
    """
    tokens = []
    i = 0
    while i < len(text):
        c = text[i]

        # Skip whitespace
        if c.isspace():
            # Add space as text token
            if tokens and isinstance(tokens[-1], str) and not tokens[-1].endswith(' '):
                tokens.append(' ')
            i += 1
            continue

        # Detect subscript: word_word, word_{expr}, Sum_{...}^{...}
        if c.isalpha() or c == '_':
            j = i
            while j < len(text) and (text[j].isalnum() or text[j] == '_'):
                j += 1
            word = text[i:j]
            i = j

            # _后跟{ → 花括号下标：word_{expr}
            if word.endswith('_') and i < len(text) and text[i] == '{':
                base = word[:-1]  # 去掉末尾_
                depth, k = 1, i + 1
                while k < len(text) and depth > 0:
                    if text[k] == '{': depth += 1
                    elif text[k] == '}': depth -= 1
                    k += 1
                sub_text = text[i+1:k-1]
                i = k
                # 检查后面是否有 ^ 上标
                sup_text = ''
                if i < len(text) and text[i] == '^':
                    if i + 1 < len(text) and text[i+1] == '{':
                        depth2, k2 = 1, i + 2
                        while k2 < len(text) and depth2 > 0:
                            if text[k2] == '{': depth2 += 1
                            elif text[k2] == '}': depth2 -= 1
                            k2 += 1
                        sup_text = text[i+2:k2-1]
                        i = k2
                    elif i + 1 < len(text) and text[i+1].isalnum():
                        k2 = i + 1
                        while k2 < len(text) and text[k2].isalnum(): k2 += 1
                        sup_text = text[i+1:k2]
                        i = k2
                # Sum/Prod → nary token
                if base in ('Sum', 'sum'):
                    tokens.append(('nary', '∑', sub_text, sup_text) if sup_text else ('nary', '∑', sub_text))
                elif base in ('Prod', 'prod'):
                    tokens.append(('nary', 'Π', sub_text, sup_text) if sup_text else ('nary', 'Π', sub_text))
                else:
                    if sup_text:
                        tokens.append(('subsup', base, sub_text, sup_text))
                    else:
                        tokens.append(('sub', base, sub_text))
                continue

            # 普通 _word 下标
            parts = word.split('_')
            if len(parts) == 2 and parts[0] and parts[1]:
                base = parts[0]
                # Sum/Prod 转换
                if base == 'Sum' or base == 'sum':
                    tokens.append(('nary', '∑', parts[1], ''))
                elif base == 'Prod' or base == 'prod':
                    tokens.append(('nary', 'Π', parts[1], ''))
                else:
                    tokens.append(('sub', base, parts[1]))
            elif len(parts) == 3 and parts[0] and parts[1] and parts[2]:
                tokens.append(('sub', parts[0], f'{parts[1]},{parts[2]}'))
            else:
                tokens.append(word)
            continue

        # Detect superscript: ^text, ^{text}, ^(expr), ²
        if c == '^' or c == '²':
            sup_text = ''
            if c == '²':
                sup_text = '2'
                i += 1
            elif i + 1 < len(text):
                if text[i + 1] == '{':
                    # ^{...} — brace superscript
                    depth, j = 1, i + 2
                    while j < len(text) and depth > 0:
                        if text[j] == '{': depth += 1
                        elif text[j] == '}': depth -= 1
                        j += 1
                    sup_text = text[i+2:j-1]
                    i = j
                elif text[i + 1] == '(':
                    # ^(expr) — parenthesized superscript
                    depth, j = 1, i + 2
                    while j < len(text) and depth > 0:
                        if text[j] == '(': depth += 1
                        elif text[j] == ')': depth -= 1
                        j += 1
                    sup_text = text[i+1:j]  # includes parentheses
                    i = j
                elif text[i + 1].isalnum():
                    # ^x — simple superscript
                    j = i + 1
                    while j < len(text) and text[j].isalnum(): j += 1
                    sup_text = text[i+1:j]
                    i = j
                else:
                    i += 1

            if sup_text:
                # Pop preceding identifier as base
                base = ''
                while tokens and isinstance(tokens[-1], str) and tokens[-1][-1].isalnum():
                    base = tokens[-1][-1] + base
                    if len(tokens[-1]) == 1:
                        tokens.pop()
                    else:
                        tokens[-1] = tokens[-1][:-1]
                        break
                if not base:
                    # Try popping a complete string token
                    while tokens and isinstance(tokens[-1], str):
                        base = tokens.pop() + base
                if not base:
                    base = 'x'
                if tokens and isinstance(tokens[-1], tuple) and tokens[-1][0] == 'sub':
                    # Promote: base_sub^sup → subsup
                    sub_tok = tokens.pop()
                    tokens.append(('subsup', sub_tok[1], sub_tok[2], sup_text))
                else:
                    tokens.append(('sup', base, sup_text))
            continue

        # Detect · as dot multiplication
        if c == '·':
            tokens.append('·')
            i += 1
            continue

        # Detect Greek letters
        greek_map = {
            'η': 'η', 'ω': 'ω', 'σ': 'σ', 'ξ': 'ξ', 'α': 'α', 'β': 'β',
            'γ': 'γ', 'δ': 'δ', 'ε': 'ε', 'θ': 'θ', 'λ': 'λ', 'μ': 'μ',
            'τ': 'τ', 'φ': 'φ', 'ζ': 'ζ', 'Δ': 'Δ', 'Σ': 'Σ', 'Ω': 'Ω',
            'ρ': 'ρ', 'π': 'π', 'χ': 'χ',
        }
        if c in greek_map:
            tokens.append(c)
            i += 1
            continue

        # Handle arrows and math symbols
        special = {
            '→': '→', '≤': '≤', '≥': '≥', '×': '×', '∀': '∀',
            '∈': '∈', '±': '±', '∞': '∞', '∂': '∂', '∫': '∫',
            '√': '√',
        }
        if c in special:
            tokens.append(c)
            i += 1
            continue

        # Everything else
        tokens.append(c)
        i += 1

    # Merge consecutive string tokens
    merged = []
    for token in tokens:
        if merged and isinstance(merged[-1], str) and isinstance(token, str):
            merged[-1] += token
        else:
            merged.append(token)
    return merged


# ---- Inline math text processing ----

_GREEK_CHARS = set(
    'αβγδεζηθικλμνξπρστυφχψωΑΒΓΔΕΖΗΘΙΚΛΜΝΞΠΡΣΤΥΦΧΨΩ'
    'ΔΩΣ'  # common uppercase duplicates for safety
)
_MATH_OPS = set('≤≥·→±×²³∂∫√∞∀∈|=−^−＋＜＞∗⁄+∑∏¬∧∨∩∪⊂⊃∈∉⊆⊇⊕⊗⊙')

def _is_math_indicator(ch):
    """Character that signals inline math mode."""
    return ch in _GREEK_CHARS or ch == '_' or ch in _MATH_OPS

# Math continuation chars: ASCII alphanumeric + structural + all math ops + underscore + space
# Space is included so that parenthesized expressions with spaces (e.g., R^(C × H × W))
# are treated as a single math segment instead of being split at each space.
_MATH_CONTINUATION = set('(),./\\-[]{}^+* ')
# NOTE: '~' intentionally excluded — in Chinese text, ~ is a range indicator (e.g., 5~10),
# not a math operator. Including it would pull numeric ranges into math segments,
# causing empty m:t elements in OMML output.
_MATH_CONTINUATION.update(_MATH_OPS)
_MATH_CONTINUATION.add('_')

def _is_math_continuation(ch):
    """Character that can continue a math segment (Latin, digits, parens, etc.)."""
    return (ch.isalpha() and ch.isascii()) or ch.isdigit() or ch in _MATH_CONTINUATION

def split_inline_math(text):
    """Split text into (segment_str, is_math) list for inline math formatting.

    A segment is marked as math if it contains Greek letters, subscripts (via _),
    or math operators. Adjacent Latin identifiers and numbers are absorbed into
    the math segment.
    """
    segments = []
    n = len(text)
    if n == 0:
        return segments

    i = 0
    buf = []
    in_math = False

    while i < n:
        ch = text[i]

        if in_math:
            if _is_math_continuation(ch):
                buf.append(ch)
            else:
                # Flush math segment
                segments.append((''.join(buf), True))
                buf = [ch]
                in_math = _is_math_indicator(ch)
        else:
            if _is_math_indicator(ch):
                # Try extending backward: grab preceding Latin letters / digits
                # that are adjacent to the math indicator (no space or Chinese in between)
                pre = ''
                if buf:
                    s = ''.join(buf)
                    # Find trailing ASCII alphanumeric / dot / paren chars
                    m = re.match(r'^(.*?)([a-zA-Z0-9_.(){}\[\],/\-]+)$', s, re.DOTALL)
                    if m:
                        pre_text = m.group(1)
                        pre_math = m.group(2)
                        if pre_math:
                            # Only absorb if it looks like a variable identifier
                            # (starts with letter or is short numeric)
                            if pre_math[0].isalpha() or len(pre_math) <= 3:
                                if pre_text:
                                    segments.append((pre_text, False))
                                buf = [pre_math + ch]
                                in_math = True
                                i += 1
                                continue
                    # Flush ordinary buffer
                    segments.append((s, False))
                    buf = [ch]
                    in_math = True
                else:
                    buf.append(ch)
                    in_math = True
            else:
                buf.append(ch)

        i += 1

    if buf:
        segments.append((''.join(buf), in_math))

    return segments


def add_inline_math_paragraph(doc, text, after_element=None,
                               normal_font='宋体', normal_size=Pt(12),
                               first_line_indent=Cm(0.74), line_spacing=1.5,
                               bold=False, alignment=None):
    """Create a paragraph with inline math rendered as OMML elements.

    Math segments are rendered as proper OMML (m:oMath) with subscript/superscript
    positioning, Greek letters in Cambria Math — matching display formula typography.
    OMML elements and text runs are interleaved as siblings within the paragraph.

    Args:
        doc: python-docx Document
        text: paragraph text
        after_element: XML element to insert after
        normal_font: font name for regular text (default 宋体)
        normal_size: font size for regular text (default 12pt)
        first_line_indent: paragraph first line indent
        line_spacing: line spacing multiplier
        bold: whether the entire paragraph is bold
        alignment: paragraph alignment (WD_ALIGN_PARAGRAPH or None)

    Returns:
        p._element (the inserted paragraph XML element)
    """
    from docx.oxml import OxmlElement

    segments = split_inline_math(text)

    p = doc.add_paragraph()
    pPr = p._element.get_or_add_pPr()

    if alignment is not None:
        p.alignment = alignment

    p.paragraph_format.first_line_indent = first_line_indent
    p.paragraph_format.line_spacing = line_spacing

    # Remove any default empty run added by doc.add_paragraph()
    for child in list(p._element):
        if child.tag == qn('w:r') and not child.findall('.//' + qn('w:t')):
            p._element.remove(child)

    builder = OMMLEq()
    font_half_pts = str(int(round(normal_size.pt * 2)))

    for seg_text, is_math in segments:
        if not seg_text:
            continue

        if is_math:
            try:
                tokens = parse_formula(seg_text)
                omath = builder.build_formula(tokens)
                # Apply font size + Cambria Math to every m:r inside the omath
                for mr in omath.iter(qn('m:r')):
                    w_rPr = mr.find(qn('w:rPr'))
                    if w_rPr is None:
                        w_rPr = OxmlElement('w:rPr')
                        mr.insert(0, w_rPr)
                    # font size
                    sz = w_rPr.find(qn('w:sz'))
                    if sz is None:
                        sz = OxmlElement('w:sz')
                        w_rPr.append(sz)
                    sz.set(qn('w:val'), font_half_pts)
                    # Cambria Math font
                    rFonts = w_rPr.find(qn('w:rFonts'))
                    if rFonts is None:
                        rFonts = OxmlElement('w:rFonts')
                        w_rPr.append(rFonts)
                    rFonts.set(qn('w:ascii'), 'Cambria Math')
                    rFonts.set(qn('w:hAnsi'), 'Cambria Math')
                p._element.append(omath)
            except Exception:
                # Fallback: plain Cambria Math run
                rn = p.add_run(seg_text)
                rn.font.name = 'Cambria Math'
                rn.font.size = normal_size
                rn._element.rPr.rFonts.set(qn('w:ascii'), 'Cambria Math')
                rn._element.rPr.rFonts.set(qn('w:hAnsi'), 'Cambria Math')
                if bold:
                    rn.font.bold = True
        else:
            rn = p.add_run(seg_text)
            rn.font.name = normal_font
            rn.font.size = normal_size
            rn._element.rPr.rFonts.set(qn('w:ascii'), normal_font)
            rn._element.rPr.rFonts.set(qn('w:hAnsi'), normal_font)
            rn._element.rPr.rFonts.set(qn('w:eastAsia'), normal_font)
            if bold:
                rn.font.bold = True

    # Insert after specified element
    body = doc.element.body
    body.remove(p._element)
    if after_element is not None:
        after_element.addnext(p._element)

    return p._element


def add_omath_paragraph(doc, formula_text, eq_number, after_element=None, font_size=12):
    """Add a paragraph with OMML formula centered and equation number right-aligned.

    Args:
        doc: python-docx Document
        formula_text: simplified formula text like "ALCC = C_inv·CRF(r,N) + C_fom"
        eq_number: equation number like "式(3.5.1-1)"
        after_element: XML element to insert after (or None to append)
        font_size: font size in pt
    """
    from docx.oxml import OxmlElement

    # Parse formula into tokens
    tokens = parse_formula(formula_text)

    # Create paragraph with tab stops (center + right)
    p = doc.add_paragraph()
    pPr = p._element.get_or_add_pPr()

    # Set paragraph alignment
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT

    # Add tab stops: center at page center, right at page right
    # For A4 with standard margins, center ~7.5cm from left, right ~15cm
    tabs = OxmlElement('w:tabs')

    center_tab = OxmlElement('w:tab')
    center_tab.set(qn('w:val'), 'center')
    center_tab.set(qn('w:pos'), '4536')  # ~8cm in twips (1/20 pt)
    tabs.append(center_tab)

    right_tab = OxmlElement('w:tab')
    right_tab.set(qn('w:val'), 'right')
    right_tab.set(qn('w:pos'), '9072')  # ~16cm in twips
    tabs.append(right_tab)

    pPr.append(tabs)

    # Add tab character before OMath (to center formula)
    tab_run_before = OxmlElement('w:r')
    tab_char_before = OxmlElement('w:tab')
    tab_run_before.append(tab_char_before)
    p._element.append(tab_run_before)

    # Add OMath element with proper font styling
    omath = OxmlElement('m:oMath')

    builder = OMMLEq()
    omml_math = builder.build_formula(tokens)

    # Copy children from omml_math to omath
    # Font styling (Cambria Math) is already set inside OMMLEq._r()
    for child in list(omml_math):
        omath.append(child)

    p._element.append(omath)

    # Add tab character after formula, before equation number
    tab_run = OxmlElement('w:r')
    tab_char = OxmlElement('w:tab')
    tab_run.append(tab_char)
    p._element.append(tab_run)

    # Add equation number
    eq_run = OxmlElement('w:r')
    eq_rPr = OxmlElement('w:rPr')
    eq_sz = OxmlElement('w:sz')
    eq_sz.set(qn('w:val'), str(int(font_size * 2)))
    eq_rPr.append(eq_sz)
    eq_rFonts = OxmlElement('w:rFonts')
    eq_rFonts.set(qn('w:ascii'), '宋体')
    eq_rFonts.set(qn('w:hAnsi'), '宋体')
    eq_rFonts.set(qn('w:eastAsia'), '宋体')
    eq_rPr.append(eq_rFonts)
    eq_run.append(eq_rPr)
    eq_t = OxmlElement('w:t')
    eq_t.text = eq_number
    eq_t.set(qn('xml:space'), 'preserve')
    eq_run.append(eq_t)
    p._element.append(eq_run)

    # Insert after specified element
    body = doc.element.body
    if after_element is not None:
        body.remove(p._element)
        after_element.addnext(p._element)

    return p._element


# ═══════════════════════════════════════════════════════════════
# 统一 LaTeX → OMML 转换接口（供 docx-secure-renderer 调用）
# ═══════════════════════════════════════════════════════════════

def convert_latex_to_omml(latex: str) -> etree.Element:
    """
    将 LaTeX 字符串转换为 OMML XML 元素（m:oMath）。

    转换策略（按优先级）：
      1. OMMLEq 原生管线：对简化公式语法（_下标, ^上标, 希腊字母）直接构建
      2. latex2mathml → MathML → OMML：处理标准 LaTeX 公式（\\frac, \\sqrt, \\int, \\sum 等）
      3. 均失败返回 None

    调用方：仅 docx-secure-renderer.renderer.DocxSecureRenderer._render_formula()
    """
    # 策略一：OMMLEq 原生解析（适用于简化语法：_下标, ^上标, 希腊字母）
    # 优先使用 parse_formula_enhanced，解析失败则回退到 parse_formula
    try:
        tokens = None
        try:
            sys.path.insert(0, r"C:\Users\Andre Fan\.claude\skills\patent-writer")
            from formula_parser import parse_formula_enhanced
            tokens = parse_formula_enhanced(latex)
        except Exception:
            # enhanced parser failed — fall back to basic parser
            tokens = parse_formula(latex)

        builder = OMMLEq()
        omml = builder.build_formula(tokens)
        # 仅当产出包含结构化元素时才视为成功，否则回退到策略二
        children = list(omml)
        if children:
            # 检查是否包含实际OMML结构（sSub/sSup/sSubSup/f/rad/nary）
            has_structure = any(
                child.tag == qn('m:' + tag)
                for child in omml.iter()
                for tag in ['sSub', 'sSup', 'sSubSup', 'f', 'rad', 'nary', 'limLow', 'limUpp']
            )
            if has_structure:
                return omml
            # 否则：全是平文本 m:r → 不回退，让策略二处理
    except Exception:
        pass

    # 策略二：latex2mathml → MathML → OMML
    try:
        from latex2mathml.converter import convert as latex_to_mathml_str
        mathml_str = latex_to_mathml_str(latex)
        mathml_elem = ET.fromstring(mathml_str)
        omml = _mathml_to_omml(mathml_elem)
        if omml is not None:
            return omml
    except Exception:
        pass

    return None


def convert_latex_batch(latex_list: list) -> list:
    """
    批量转换 LaTeX 字符串列表为 OMML 元素列表。
    对每个输入调用 convert_latex_to_omml()，失败项返回 None。

    参数:
        latex_list: List[str] — LaTeX 公式字符串列表
    返回:
        List[etree.Element | None] — 与输入一一对应的 OMML 元素列表
    """
    return [convert_latex_to_omml(l) for l in latex_list]


# ═══════════════════════════════════════════════════════════════
# MathML → OMML 递归转换器（内部使用）
# ═══════════════════════════════════════════════════════════════

def _mathml_to_omml(mathml_elem: ET.Element) -> etree.Element:
    """递归将 MathML 元素树转换为 OMML (m:oMath) lxml 元素。"""
    tag = mathml_elem.tag.split('}')[-1] if '}' in mathml_elem.tag else mathml_elem.tag

    if tag == 'math':
        omml = etree.Element(qn('m:oMath'))
        if len(mathml_elem) > 0:
            first_child = mathml_elem[0]
            child_tag = first_child.tag.split('}')[-1] if '}' in first_child.tag else first_child.tag
            if child_tag == 'mrow':
                _convert_mrow(omml, first_child)
            else:
                _convert_mml_element(omml, first_child)
        return omml

    omml = etree.Element(qn('m:oMath'))
    _convert_mml_element(omml, mathml_elem)
    return omml


def _convert_mrow(parent, mrow):
    for child in mrow:
        _convert_mml_element(parent, child)


def _convert_mml_element(parent, elem):
    if elem is None:
        return
    # 文本节点
    if hasattr(elem, 'tag') and elem.tag is None:
        text = (elem.text or '').strip()
        if text:
            mr = etree.SubElement(parent, qn('m:r'))
            mt = etree.SubElement(mr, qn('m:t'))
            mt.text = text
            mt.set(qn('xml:space'), 'preserve')
        return

    tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag

    # mi, mn, mo, mtext
    if tag in ('mi', 'mn', 'mo', 'mtext'):
        mr = etree.SubElement(parent, qn('m:r'))
        if tag == 'mi':
            rPr = etree.SubElement(mr, qn('m:rPr'))
            sty = etree.SubElement(rPr, qn('m:sty'))
            sty.set(qn('m:val'), 'i')
        mt = etree.SubElement(mr, qn('m:t'))
        mt.text = _mml_extract_text(elem)
        mt.set(qn('xml:space'), 'preserve')
        return

    # mrow
    if tag == 'mrow':
        for child in elem:
            _convert_mml_element(parent, child)
        if elem.text and elem.text.strip():
            mr = etree.SubElement(parent, qn('m:r'))
            mt = etree.SubElement(mr, qn('m:t'))
            mt.text = elem.text.strip()
            mt.set(qn('xml:space'), 'preserve')
        return

    # mfrac
    if tag == 'mfrac':
        f = etree.SubElement(parent, qn('m:f'))
        num = etree.SubElement(f, qn('m:num'))
        den = etree.SubElement(f, qn('m:den'))
        children = list(elem)
        if len(children) >= 2:
            _convert_mml_element(num, children[0])
            _convert_mml_element(den, children[1])
        elif len(children) == 1:
            _convert_mml_element(num, children[0])
        return

    # msqrt
    if tag == 'msqrt':
        rad = etree.SubElement(parent, qn('m:rad'))
        radPr = etree.SubElement(rad, qn('m:radPr'))
        degHide = etree.SubElement(radPr, qn('m:degHide'))
        degHide.set(qn('m:val'), '1')
        e = etree.SubElement(rad, qn('m:e'))
        for child in elem:
            _convert_mml_element(e, child)
        return

    # msub
    if tag == 'msub':
        sSub = etree.SubElement(parent, qn('m:sSub'))
        base = etree.SubElement(sSub, qn('m:e'))
        sub = etree.SubElement(sSub, qn('m:sub'))
        children = list(elem)
        if len(children) >= 2:
            _convert_mml_element(base, children[0])
            _convert_mml_element(sub, children[1])
        elif len(children) == 1:
            _convert_mml_element(base, children[0])
        return

    # msup
    if tag == 'msup':
        sSup = etree.SubElement(parent, qn('m:sSup'))
        base = etree.SubElement(sSup, qn('m:e'))
        sup = etree.SubElement(sSup, qn('m:sup'))
        children = list(elem)
        if len(children) >= 2:
            _convert_mml_element(base, children[0])
            _convert_mml_element(sup, children[1])
        elif len(children) == 1:
            _convert_mml_element(base, children[0])
        return

    # msubsup
    if tag == 'msubsup':
        sSubSup = etree.SubElement(parent, qn('m:sSubSup'))
        base = etree.SubElement(sSubSup, qn('m:e'))
        sub = etree.SubElement(sSubSup, qn('m:sub'))
        sup = etree.SubElement(sSubSup, qn('m:sup'))
        children = list(elem)
        if len(children) >= 3:
            _convert_mml_element(base, children[0])
            _convert_mml_element(sub, children[1])
            _convert_mml_element(sup, children[2])
        elif len(children) >= 2:
            _convert_mml_element(base, children[0])
            _convert_mml_element(sub, children[1])
        elif len(children) == 1:
            _convert_mml_element(base, children[0])
        return

    # mover
    if tag == 'mover':
        limUpp = etree.SubElement(parent, qn('m:limUpp'))
        e = etree.SubElement(limUpp, qn('m:e'))
        lim = etree.SubElement(limUpp, qn('m:lim'))
        children = list(elem)
        if len(children) >= 2:
            _convert_mml_element(e, children[0])
            _convert_mml_element(lim, children[1])
        return

    # munder
    if tag == 'munder':
        limLow = etree.SubElement(parent, qn('m:limLow'))
        e = etree.SubElement(limLow, qn('m:e'))
        lim = etree.SubElement(limLow, qn('m:lim'))
        children = list(elem)
        if len(children) >= 2:
            _convert_mml_element(e, children[0])
            _convert_mml_element(lim, children[1])
        return

    # munderover (sum/prod/integral with limits)
    if tag == 'munderover':
        children = list(elem)
        if len(children) >= 3:
            nary = etree.SubElement(parent, qn('m:nary'))
            naryPr = etree.SubElement(nary, qn('m:naryPr'))
            chr_e = etree.SubElement(naryPr, qn('m:chr'))
            op_text = _mml_extract_text(children[0]) if children else '∑'
            chr_e.set(qn('m:val'), op_text)
            grow = etree.SubElement(naryPr, qn('m:grow'))
            grow.set(qn('m:val'), '1')
            sub_e = etree.SubElement(nary, qn('m:sub'))
            sup_e = etree.SubElement(nary, qn('m:sup'))
            e = etree.SubElement(nary, qn('m:e'))
            _convert_mml_element(sub_e, children[1])
            _convert_mml_element(sup_e, children[2])
            _convert_mml_element(e, children[0])
        return

    # mstyle
    if tag == 'mstyle':
        for child in elem:
            _convert_mml_element(parent, child)
        return

    # 通用：递归子元素
    if len(elem) > 0:
        for child in elem:
            _convert_mml_element(parent, child)
    else:
        text = _mml_extract_text(elem).strip()
        if text:
            mr = etree.SubElement(parent, qn('m:r'))
            mt = etree.SubElement(mr, qn('m:t'))
            mt.text = text
            mt.set(qn('xml:space'), 'preserve')


def _mml_extract_text(elem) -> str:
    """递归提取 MathML 元素的所有文本。"""
    if elem is None:
        return ''
    tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
    if tag in ('mtext', 'mi', 'mn', 'mo'):
        text = elem.text or ''
        for child in elem:
            text += _mml_extract_text(child)
            text += child.tail or ''
        return text
    text = elem.text or ''
    for child in elem:
        text += _mml_extract_text(child)
        text += child.tail or ''
    return text
