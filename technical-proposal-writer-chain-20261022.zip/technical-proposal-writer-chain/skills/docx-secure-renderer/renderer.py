"""
DOCX Secure Renderer v2 — 系统中唯一被授权生成 .docx 文件的安全渲染层。

v2 新增能力：
  - 图片完整嵌入（本地路径 + 网络URL），最大宽度14cm
  - LaTeX公式 → Word原生OMath（omml-helper 优先 → latex2mathml 回退 → matplotlib 图片终极回退）
  - 公式渲染回退方案（matplotlib mathtext → 图片）
  - 媒体完整性校验（图片N/M + 公式N/M 统计）
  - 三种处理流程（新建 / 修改 / 操作日志重放）
  - 逐项容错：单个图片/公式失败不中断整体生成

公式处理链（内部调用，对外透明）：
  omml_helper.convert_latex_to_omml(LaTeX) → OMML XML
  ├── 策略1: OMMLEq 原生解析（_下标, ^上标, 希腊字母）
  ├── 策略2: latex2mathml → MathML → OMML（\\frac, \\sqrt, \\int, \\sum 等）
  └── 策略3: matplotlib mathtext → PNG 图片嵌入（终极回退，由 renderer 执行）

铁律：
  1. 内容与样式分离 — Markdown编辑，OOXML仅最终渲染
  2. Word文件即最终制品 — 一旦生成即只读
  3. 整文档重生成 — 绝不修复已损坏的docx
  4. 强制结构自检 — 每次生成后立即校验
"""
import os, re, io, sys, tempfile, hashlib, traceback
from pathlib import Path
from urllib.parse import urlparse
from typing import Optional, Tuple, List, Dict, Any
from dataclasses import dataclass, field

from docx import Document
from docx.shared import Pt, Inches, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml, OxmlElement
from lxml import etree

# 导入独立解析器
from md_parser import parse_markdown, split_inline_formulas, MediaTracker, MDElement

# 导入 omml-helper 作为内部公式转换引擎
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
try:
    from omml_helper import convert_latex_to_omml as _omml_convert, convert_latex_batch
    _HAS_OMML_HELPER = True
except ImportError:
    _HAS_OMML_HELPER = False
    _omml_convert = None
    convert_latex_batch = None
from PIL import Image as PILImage

# ─── 模板名 → 路径 ─────────────────────────────────────────────
TEMPLATE_MAPPING = {
    "tech-guide": "D:/shared/templates/tech-guide.docx",
    "api-reference": "D:/shared/templates/api-reference.docx",
    "patent": "D:/shared/templates/patent-template.docx",
}
WORKING_DIR = Path(r"C:\Users\Andre Fan")


# ═══════════════════════════════════════════════════════════════
# 媒体追踪器
# ═══════════════════════════════════════════════════════════════



# ═══════════════════════════════════════════════════════════════
# LaTeX 净化器（修复 Python 字符串转义对 LaTeX 命令的污染）
# ═══════════════════════════════════════════════════════════════
_LATEX_ESCAPE_FIX = {
    '\x07': r'\a',   # BEL  → \alpha, \arg ...
    '\x08': r'\b',   # BS   → \beta, \bmod ...
    '\x0c': r'\f',   # FF   → \frac, \flat ...
    '\x0b': r'\v',   # VT   → \vec, \vdots ...
    '\x0a': r'\n',   # LF   → \neq, \neg ... (XML-valid but LaTeX-corrupting)
    '\x0d': r'\r',   # CR   → \rho, \right ...
    '\x09': r'\t',   # TAB  → \times, \tan ...
}

def _sanitize_latex(latex: str) -> str:
    """将 Python 转义产生的控制字符还原为 LaTeX 反斜杠命令。"""
    for ctrl, replacement in _LATEX_ESCAPE_FIX.items():
        latex = latex.replace(ctrl, replacement)
    return latex


# ═══════════════════════════════════════════════════════════════
# 公式处理：LaTeX → OMML（委托 omml-helper → latex2mathml → matplotlib）
# ═══════════════════════════════════════════════════════════════
# 公式转换层次：
#   Layer 1: omml_helper.convert_latex_to_omml() — OMMLEq 原生 + latex2mathml
#   Layer 2: matplotlib mathtext → PNG（由 _render_formula_as_image 执行）
# 调用方无需知晓内部细节，只需在 Markdown 中写 $...$ 或 $$...$$ 即可。

def latex_to_omath(latex: str, display_mode: bool = False) -> Optional[object]:
    """
    将 LaTeX 公式转换为 Word OMML 元素或图片（BytesIO）。
    优先调用 omml-helper，失败时回退到 matplotlib 图片渲染。
    display_mode 参数保留接口兼容，实际处理由调用方控制段落对齐。
    """
    latex = _sanitize_latex(latex)  # 修复Python转义对LaTeX命令的污染

    # Layer 1: 委托 omml-helper（OMMLEq 原生 → latex2mathml → MathML→OMML）
    if _HAS_OMML_HELPER:
        try:
            result = _omml_convert(latex)
            if result is not None:
                return result
        except Exception:
            pass

    # Layer 2: matplotlib mathtext → PNG 图片（终极回退）
    try:
        return _render_formula_as_image(latex)
    except Exception:
        return None


def _render_formula_as_image(latex: str) -> Optional[object]:
    """使用 matplotlib mathtext 将公式渲染为图片，返回嵌入图片的 run 元素。"""
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(4, 0.5))
        ax.axis('off')
        ax.text(0.5, 0.5, f'${latex}$', transform=ax.transAxes,
                fontsize=12, ha='center', va='center')
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=150, bbox_inches='tight',
                    pad_inches=0.05, transparent=True)
        plt.close(fig)
        buf.seek(0)
        return buf
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════
# 图片处理
# ═══════════════════════════════════════════════════════════════
def fetch_image(path_or_url: str) -> Optional[io.BytesIO]:
    """获取图片数据。支持本地路径和网络URL。"""
    # 本地绝对路径
    p = Path(path_or_url)
    if p.exists():
        try:
            return io.BytesIO(p.read_bytes())
        except Exception:
            return None

    # 相对于工作目录
    local = WORKING_DIR / path_or_url
    if local.exists():
        try:
            return io.BytesIO(local.read_bytes())
        except Exception:
            return None

    # 绝对路径二次检查（处理Windows盘符）
    if path_or_url.startswith('D:') or path_or_url.startswith('C:'):
        try:
            return io.BytesIO(Path(path_or_url).read_bytes())
        except Exception:
            return None

    # 网络URL
    try:
        import urllib.request
        req = urllib.request.Request(path_or_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=30) as resp:
            return io.BytesIO(resp.read())
    except Exception:
        return None


def guess_image_ext(data: io.BytesIO) -> str:
    """根据文件头判断图片格式。"""
    header = data.read(8)
    data.seek(0)
    if header.startswith(b'\x89PNG'):
        return 'png'
    elif header.startswith(b'\xff\xd8'):
        return 'jpeg'
    elif header.startswith(b'GIF'):
        return 'gif'
    elif header.startswith(b'RIFF'):
        return 'webp'
    elif header.startswith(b'<?xml') or header.startswith(b'<svg'):
        return 'svg'
    return 'png'


# ═══════════════════════════════════════════════════════════════
# 样式工具
# ═══════════════════════════════════════════════════════════════
def set_run_font(run, name_cn="微软雅黑", name_en="Calibri", size=Pt(11),
                 color=None, bold=False, italic=False):
    run.font.size = size
    run.bold = bold
    run.italic = italic
    run.font.name = name_en
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = parse_xml(f'<w:rFonts {nsdecls("w")} />')
        rPr.insert(0, rFonts)
    rFonts.set(qn('w:eastAsia'), name_cn)
    rFonts.set(qn('w:ascii'), name_en)
    rFonts.set(qn('w:hAnsi'), name_en)
    if color:
        run.font.color.rgb = color


# ═══════════════════════════════════════════════════════════════
# 主渲染器
# ═══════════════════════════════════════════════════════════════
class DocxSecureRenderer:
    """DOCX 安全渲染器 v2。"""

    def __init__(self, working_dir: str = None):
        self.working_dir = Path(working_dir) if working_dir else WORKING_DIR
        self._h1_count = 0    # 跟踪 H1：第一个用 Title
        self._eq_counter = 0  # 行间公式自动编号

    # ── 公开接口 ──────────────────────────────────────────────

    def generate(self, template_name: str, content_markdown: str,
                 template_path: str = None, recipe_json: dict = None,
                 output_path: str = None) -> dict:
        """
        流程A/B：渲染文档 → 格式审计 → 校验 → 返回完整结果。
        """
        template_file = _resolve_template(template_name, template_path)

        if recipe_json:
            content_markdown = self._apply_recipe(recipe_json)

        tracker = MediaTracker()
        output_file = str(self.working_dir / (output_path or "output.docx"))

        try:
            self._render(template_file, content_markdown, output_file, tracker)
        except Exception as e:
            return _fail_result(output_file, content_markdown, template_name, tracker, str(e))

        # ── 格式审计与自动修正 ──
        audit_report = format_audit_and_fix(output_file, template_file)
        if audit_report:
            print(audit_report)

        # ── 结构校验 ──
        is_valid, err_info = self.validate(output_file)
        if not is_valid:
            return {
                'success': False, 'fatal': True,
                'message': f'❌ 文档生成失败。{err_info}\n建议：回滚到上一个完好状态，从Markdown重新生成。',
                'output_path': output_file, 'markdown_snapshot': content_markdown,
                'template_name': template_name, 'media_tracker': tracker,
            }

        # ── 构建消息 ──
        validate_warnings = ''
        if err_info and err_info.startswith('⚠️'):
            validate_warnings = '\n' + err_info

        if tracker.all_ok and not validate_warnings:
            msg = (
                f'✅ 文档生成成功\n'
                f'文件路径：{output_file}\n'
                f'模板：{template_name}\n'
                f'结构校验：通过\n'
                f'媒体完整性：图片 [{tracker.image_report}] | 公式 [{tracker.formula_report}]'
            )
        else:
            issues = []
            for f in tracker.images_failed:
                issues.append(f'  - 图片 {f} → 文件不存在或无法读取')
            for f in tracker.formulas_failed:
                issues.append(f'  - 公式 ${f}$ → 转换失败')
            msg = (
                f'⚠️ 文档生成完成，但存在非致命问题\n'
                f'文件路径：{output_file}\n'
                f'模板：{template_name}\n'
                f'结构校验：通过\n'
                f'媒体完整性：图片 [{tracker.image_report}] | 公式 [{tracker.formula_report}]\n'
                f'未成功渲染的项目：\n' + '\n'.join(issues) + '\n'
                f'建议：检查以上路径后，修正Markdown并重新渲染。'
                f'{validate_warnings}'
            )

        return {
            'success': True, 'fatal': False,
            'message': msg, 'output_path': output_file,
            'markdown_snapshot': content_markdown,
            'template_name': template_name, 'media_tracker': tracker,
        }

    def validate(self, file_path: str) -> Tuple[bool, Optional[str]]:
        """
        结构 + 内容完整性校验。

        结构层：python-docx 打开，捕获 XML 解析错误。
        内容层（新增——所有生成 .docx 的 skill 统一受益）：
          - 图片占位符检测
          - 行间公式退化检测（仅含编号/标点 → 疑似缺少数学表达式）
          - OMML 结构空洞检测（有公式但无下标/上标/分数/根号）
          - 内嵌图片数量报告

        返回 (is_valid, error_info)。
        结构合法但内容有疑似问题时 is_valid=True，error_info 含 "⚠️" 前缀。
        """
        # ── 结构校验 ──
        try:
            doc = Document(file_path)
            _ = len(doc.paragraphs)
            _ = len(doc.sections)
        except Exception as e:
            error_str = str(e)
            try:
                filepath = Path(file_path)
                if filepath.exists():
                    tree = etree.parse(str(filepath))
                    return False, f"python-docx 解析错误（XML结构完整）: {error_str}"
            except etree.XMLSyntaxError as xe:
                line_no = getattr(xe, 'lineno', '?')
                context = ''
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        all_lines = f.readlines()
                    line_idx = int(line_no) - 1 if isinstance(line_no, (int, str)) and str(line_no).isdigit() else -1
                    if 0 <= line_idx < len(all_lines):
                        start = max(0, line_idx - 2)
                        end = min(len(all_lines), line_idx + 3)
                        context = ''.join(f'  L{i+1}: {all_lines[i].rstrip()}\n' for i in range(start, end))
                except Exception:
                    context = "无法读取XML上下文"
                return False, f"XML解析错误，行号 {line_no}: {xe.msg}\n附近XML片段:\n{context}"
            except Exception:
                return False, f"文件校验异常: {error_str}"

        # ── 内容完整性校验 ──
        warnings = []
        ns_m = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
        ns_w = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
        ns_a = 'http://schemas.openxmlformats.org/drawingml/2006/main'

        # 1. 图片占位符检测
        placeholder_count = 0
        for p in doc.paragraphs:
            if '此处插入图片' in p.text or '图片丢失' in p.text or '图片未能加载' in p.text:
                placeholder_count += 1
        if placeholder_count > 0:
            warnings.append(
                f"发现 {placeholder_count} 个图片占位符段落（'此处插入图片'/'图片丢失'）——"
                f"请检查构建代码中图片路径是否有效"
            )

        # 2. 内嵌图片统计
        blips = len(doc.element.findall(f'.//{{{ns_a}}}blip'))
        # 也检查旧的 drawingML fallback
        if blips == 0:
            blips = len(doc.inline_shapes)
        if blips == 0 and placeholder_count == 0:
            # 只有完全没有图片也不报占位符时才提示（可能确实不需要图片）
            pass  # 不强制要求有图片

        # 3. 行间公式内容退化检测
        trivial_formula_count = 0
        trivial_pattern = re.compile(r'^[\s\(\)\[\]\d,.\-–—]+$')
        for p in doc.paragraphs:
            pPr = p._element.find(f'{{{ns_w}}}pPr')
            has_tabs = pPr is not None and pPr.find(f'{{{ns_w}}}tabs') is not None
            if has_tabs:
                omaths = p._element.findall(f'.//{{{ns_m}}}oMath')
                if omaths:
                    for om in omaths:
                        texts = []
                        for mt in om.iter(f'{{{ns_m}}}t'):
                            if mt.text:
                                texts.append(mt.text)
                        formula_str = ''.join(texts).strip()
                        if trivial_pattern.match(formula_str) and len(formula_str) < 10:
                            trivial_formula_count += 1
                            break
        if trivial_formula_count > 0:
            warnings.append(
                f"发现 {trivial_formula_count} 个行间公式疑似仅含编号（如'(1)'）——"
                f"请检查构建代码中 pb.f() 是否传入了实际数学表达式而非仅编号"
            )

        # 4. OMML 结构空洞检测
        om_total = len(doc.element.findall(f'.//{{{ns_m}}}oMath'))
        om_sub = len(doc.element.findall(f'.//{{{ns_m}}}sSub'))
        om_sup = len(doc.element.findall(f'.//{{{ns_m}}}sSup'))
        om_subsup = len(doc.element.findall(f'.//{{{ns_m}}}sSubSup'))
        if om_total > 10 and om_sub == 0 and om_sup == 0 and om_subsup == 0:
            warnings.append(
                f"文档含 {om_total} 个 OMML 公式元素，但无任何下标/上标结构——"
                f"可能存在公式内容缺失（所有公式被渲染为纯文本）"
            )

        # 5. 行间公式数量合理性
        display_count = 0
        for p in doc.paragraphs:
            pPr = p._element.find(f'{{{ns_w}}}pPr')
            if pPr is not None and pPr.find(f'{{{ns_w}}}tabs') is not None:
                if p._element.findall(f'.//{{{ns_m}}}oMath'):
                    display_count += 1
        if display_count == 0 and om_total > 0:
            warnings.append(
                f"文档含 {om_total} 个 OMML 元素但无行间公式——"
                f"所有公式均为行内，可能缺少块级公式"
            )

        if warnings:
            return True, "⚠️ 内容警告:\n  - " + "\n  - ".join(warnings)

        return True, None

    # ── 内部渲染 ──────────────────────────────────────────────

    def _render(self, template_file: str, markdown_content: str,
                output_file: str, tracker: MediaTracker):
        elements = parse_markdown(markdown_content, tracker)
        template_doc = Document(template_file)
        available_styles = {s.name for s in template_doc.styles if s.name}

        doc = Document(template_file)
        # 清空模板内容
        body = doc.element.body
        paras_to_remove = body.findall(qn('w:p'))
        for p in paras_to_remove:
            body.remove(p)
        tables_to_remove = body.findall(qn('w:tbl'))
        for t in tables_to_remove:
            body.remove(t)

        for elem in elements:
            self._render_element(doc, elem, available_styles, tracker)

        doc.save(output_file)

    def _render_element(self, doc, elem, styles, tracker):
        t = elem.type
        if t == 'heading':
            self._render_heading(doc, elem, styles, tracker)
        elif t == 'paragraph':
            self._render_paragraph(doc, elem, styles, tracker)
        elif t == 'code':
            self._render_code_block(doc, elem, styles)
        elif t == 'table':
            self._render_table(doc, elem, styles, tracker)
        elif t == 'list':
            self._render_list(doc, elem, styles)
        elif t == 'blockquote':
            self._render_blockquote(doc, elem, styles)
        elif t == 'image':
            self._render_image(doc, elem, tracker, styles)
        elif t == 'formula_block':
            self._render_formula(doc, elem.content, display=True, tracker=tracker)
        elif t == 'formula_inline':
            self._render_formula(doc, elem.content, display=False, tracker=tracker)
        elif t == 'hr':
            self._render_hr(doc)

    def _render_heading(self, doc, elem, styles, tracker):
        level = min(elem.level, 4)
        # 第一个 H1 使用 Title 样式（专利模板：黑体16pt居中）
        if level == 1:
            self._h1_count += 1
            if self._h1_count == 1 and 'Title' in styles:
                style_name = 'Title'
            else:
                style_name = 'Heading 1'
        else:
            style_name = f'Heading {level}'
        p = doc.add_paragraph(style=style_name) if style_name in styles else doc.add_paragraph()

        parts = split_inline_formulas(elem.content)
        for text, ftype in parts:
            if ftype == 'text':
                run = p.add_run(text)
                # 样式已控制字体，不再调用 set_run_font 覆盖
            else:
                omml = latex_to_omath(text, display_mode=False)
                if omml is not None:
                    self._insert_omath(p, omml)
                    tracker.formulas_succeeded += 1
                else:
                    run = p.add_run(f'[公式转换失败: {text}]')
                    run.font.color.rgb = RGBColor(0xCC, 0x00, 0x00)
                    tracker.formulas_failed.append(text)

    def _render_paragraph(self, doc, elem, styles, tracker):
        p = doc.add_paragraph()  # 使用 Normal 样式，模板定义字体
        parts = split_inline_formulas(elem.content)
        for text, ftype in parts:
            if ftype == 'text':
                self._add_inline_runs(p, text, styles)
            else:
                omml = latex_to_omath(text, display_mode=False)
                if omml is not None:
                    self._insert_omath(p, omml)
                    tracker.formulas_succeeded += 1
                else:
                    run = p.add_run(f'[公式转换失败: {text}]')
                    run.font.color.rgb = RGBColor(0xCC, 0x00, 0x00)
                    tracker.formulas_failed.append(text)

    def _add_inline_runs(self, p, text, styles):
        """解析内联 Markdown 并追加到段落。普通文本和 bold/italic 继承段落样式，仅 code 设置专用字体。"""
        pattern = r'(\*\*(.+?)\*\*)|(\*(.+?)\*)|(`(.+?)`)'
        last = 0
        for m in re.finditer(pattern, text):
            if m.start() > last:
                p.add_run(text[last:m.start()])  # 继承段落样式
            if m.group(1):  # **bold**
                run = p.add_run(m.group(2))
                run.bold = True
            elif m.group(3):  # *italic*
                run = p.add_run(m.group(4))
                run.italic = True
            elif m.group(5):  # `code`
                code_text = m.group(6)
                if 'InlineCode' in styles:
                    p.add_run(code_text, style='InlineCode')
                else:
                    run = p.add_run(code_text)
                    run.font.name = 'Consolas'
                    run.font.size = Pt(9.5)
                    run.font.color.rgb = RGBColor(0xCC, 0x33, 0x33)
            last = m.end()
        if last < len(text):
            p.add_run(text[last:])  # 继承段落样式

    def _render_code_block(self, doc, elem, styles):
        if 'CodeBlock' in styles:
            p = doc.add_paragraph(style='CodeBlock')
        else:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.8)
            p.paragraph_format.line_spacing = 1.0
        run = p.add_run(elem.content)
        set_run_font(run, name_en='Consolas', size=Pt(9.5), color=RGBColor(0x1A, 0x1A, 0x2E))

    def _render_table_cell(self, p, content, styles, tracker, bold=False):
        """在表格单元格中使用与正文一致的行内 OMML 渲染流程。"""
        parts = split_inline_formulas(content)
        for text, ftype in parts:
            if ftype == 'text':
                self._add_inline_runs(p, text, styles)
            else:
                omml = latex_to_omath(text, display_mode=False)
                if omml is not None:
                    self._insert_omath(p, omml)
                    tracker.formulas_succeeded += 1
                else:
                    run = p.add_run(f'[公式转换失败: {text}]')
                    run.font.color.rgb = RGBColor(0xCC, 0x00, 0x00)
                    tracker.formulas_failed.append(text)
        for run in p.runs:
            set_run_font(run, bold=bold, size=Pt(10))

    def _render_table(self, doc, elem, styles, tracker):
        lines = elem.content.strip().split('\n')
        if len(lines) < 2:
            return
        header = [c.strip() for c in lines[0].strip('|').split('|')]
        data = []
        for line in lines[2:]:
            data.append([c.strip() for c in line.strip('|').split('|')])
        ncols = len(header)

        table = doc.add_table(rows=1 + len(data), cols=ncols)
        # 边框由 format_audit_and_fix 统一设为三线表

        for j, h in enumerate(header):
            cell = table.cell(0, j)
            p = cell.paragraphs[0]
            self._render_table_cell(p, h, styles, tracker, bold=True)
        for i, row in enumerate(data):
            for j, val in enumerate(row):
                if j < ncols:
                    cell = table.cell(i + 1, j)
                    p = cell.paragraphs[0]
                    self._render_table_cell(p, val, styles, tracker)

    def _render_list(self, doc, elem, styles):
        if 'BulletList' in styles:
            p = doc.add_paragraph(style='BulletList')
        else:
            p = doc.add_paragraph()
        prefix = "• " if not elem.meta.get('ordered') else "1. "
        run = p.add_run(prefix + elem.content)
        set_run_font(run)

    def _render_blockquote(self, doc, elem, styles):
        if 'NoteBlock' in styles:
            p = doc.add_paragraph(style='NoteBlock')
        else:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.5)
        run = p.add_run(elem.content)
        set_run_font(run, italic=True, color=RGBColor(0x55, 0x55, 0x55), size=Pt(10))

    def _render_image(self, doc, elem, tracker: MediaTracker, styles: set = None):
        url = elem.meta.get('url', '')
        alt = elem.content or ''
        img_data = fetch_image(url)
        if img_data:
            ext = guess_image_ext(img_data)
            with tempfile.NamedTemporaryFile(suffix=f'.{ext}', delete=False) as tmp:
                tmp.write(img_data.read())
                tmp_path = tmp.name
            try:
                # 计算合适尺寸
                try:
                    pil_img = PILImage.open(tmp_path)
                    w_px, h_px = pil_img.size
                    max_w_cm = 14.0
                    dpi = pil_img.info.get('dpi', (72, 72))[0] or 72
                    w_cm = w_px / dpi * 2.54
                    if w_cm > max_w_cm:
                        w_cm = max_w_cm
                except Exception:
                    w_cm = 12.0

                p = doc.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                run = p.add_run()
                run.add_picture(tmp_path, width=Cm(w_cm))
                if alt:
                    # 优先使用模板 Caption 样式，回退到 Normal+居中+无缩进
                    if 'Caption' in styles:
                        cap = doc.add_paragraph(style='Caption')
                    else:
                        cap = doc.add_paragraph()
                        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
                        cap.paragraph_format.first_line_indent = Cm(0)
                    cap.add_run(alt)  # 字体由样式控制，不设 Run 级覆盖
                tracker.images_succeeded += 1
            finally:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
        else:
            # 容错：插入占位文本
            p = doc.add_paragraph()
            run = p.add_run(f'[图片丢失: {url}]')
            set_run_font(run, size=Pt(10), color=RGBColor(0xCC, 0x00, 0x00), italic=True)
            tracker.images_failed.append(url)

    def _render_formula(self, doc, latex: str, display: bool, tracker: MediaTracker):
        omml = latex_to_omath(latex, display_mode=display)
        if omml is not None:
            # 检查是否是图片（BytesIO）
            if isinstance(omml, io.BytesIO):
                # matplotlib fallback → 嵌入图片
                with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
                    tmp.write(omml.read())
                    tmp_path = tmp.name
                try:
                    p = doc.add_paragraph()
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    run = p.add_run()
                    run.add_picture(tmp_path, width=Cm(12))
                    tracker.formulas_succeeded += 1
                finally:
                    try:
                        os.unlink(tmp_path)
                    except OSError:
                        pass
            else:
                # OMML 元素 → 嵌入段落
                p = doc.add_paragraph()
                if display:
                    # 行间公式：制表位居中 + 编号右对齐
                    self._eq_counter += 1
                    eq_num = f"({self._eq_counter})"
                    pPr = p._element.get_or_add_pPr()
                    tabs = parse_xml(
                        f'<w:tabs {nsdecls("w")}>'
                        f'<w:tab w:val="center" w:pos="4536"/>'
                        f'<w:tab w:val="right" w:pos="9072"/>'
                        f'</w:tabs>'
                    )
                    pPr.append(tabs)
                    # 前导 tab → OMML → 后导 tab → 编号
                    tab1 = OxmlElement('w:r'); tc1 = OxmlElement('w:tab'); tab1.append(tc1)
                    p._element.append(tab1)
                    p._element.append(omml)
                    tab2 = OxmlElement('w:r'); tc2 = OxmlElement('w:tab'); tab2.append(tc2)
                    p._element.append(tab2)
                    num_run = OxmlElement('w:r')
                    num_t = OxmlElement('w:t'); num_t.text = eq_num
                    num_t.set(qn('xml:space'), 'preserve')
                    num_run.append(num_t)
                    p._element.append(num_run)
                else:
                    p._element.append(omml)
                tracker.formulas_succeeded += 1
        else:
            p = doc.add_paragraph()
            if display:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(f'[公式转换失败: {latex}]')
            set_run_font(run, size=Pt(10), color=RGBColor(0xCC, 0x00, 0x00), italic=True)
            tracker.formulas_failed.append(latex)

    def _insert_omath(self, paragraph, omml_elem):
        """将 OMML 元素插入段落（行内公式）。"""
        # 创建一个空的 run 然后追加 OMML
        run_elem = OxmlElement('w:r')
        run_elem.append(omml_elem)
        paragraph._element.append(run_elem)

    def _render_hr(self, doc):
        p = doc.add_paragraph()
        pPr = p._element.get_or_add_pPr()
        pBdr = parse_xml(
            f'<w:pBdr {nsdecls("w")}>'
            f'<w:bottom w:val="single" w:sz="6" w:space="1" w:color="999999"/>'
            f'</w:pBdr>'
        )
        pPr.append(pBdr)

    def _apply_recipe(self, recipe_json: dict) -> str:
        """基于操作日志重建 Markdown。"""
        base_md = recipe_json.get('base_markdown', '')
        ops = recipe_json.get('operations', [])
        elements = parse_markdown(base_md)
        for op in ops:
            t = op.get('type')
            idx = op.get('index', len(elements))
            if t == 'replace_block' and 0 <= idx < len(elements):
                elements[idx] = MDElement(
                    op.get('block_type', 'paragraph'),
                    content=op.get('content', ''),
                    level=op.get('level', 0),
                    meta=op.get('meta', {}))
            elif t == 'insert_block':
                elements.insert(min(idx, len(elements)), MDElement(
                    op.get('block_type', 'paragraph'),
                    content=op.get('content', ''),
                    level=op.get('level', 0),
                    meta=op.get('meta', {})))
            elif t == 'delete_block' and 0 <= idx < len(elements):
                del elements[idx]
            elif t == 'append_block':
                elements.append(MDElement(
                    op.get('block_type', 'paragraph'),
                    content=op.get('content', ''),
                    level=op.get('level', 0),
                    meta=op.get('meta', {})))
        return _elements_to_markdown(elements)

    def _apply_modification(self, previous_md: str, instruction: str) -> str:
        """
        在Markdown层面根据修改指令编辑。
        简单策略：返回带有修改注释的原Markdown，提示用户确认。
        实际使用时由调用skill的LLM在Markdown层面执行修改。
        """
        # 对于简单指令，返回原Markdown加修改标记
        # 复杂修改由调用方（通常是LLM）在调用前完成Markdown编辑
        return previous_md


def _elements_to_markdown(elements: List[MDElement]) -> str:
    lines = []
    for el in elements:
        if el.type == 'heading':
            lines.append('#' * el.level + ' ' + el.content)
        elif el.type == 'code':
            lang = el.meta.get('language', '')
            lines.append(f'```{lang}')
            lines.append(el.content)
            lines.append('```')
        elif el.type == 'table':
            lines.append(el.content)
        elif el.type == 'list':
            prefix = '- ' if not el.meta.get('ordered') else '1. '
            lines.append(prefix + el.content)
        elif el.type == 'blockquote':
            for ql in el.content.split('\n'):
                lines.append('> ' + ql)
        elif el.type == 'image':
            lines.append(f'![{el.content}]({el.meta.get("url", "")})')
        elif el.type == 'formula_block':
            lines.append(f'$${el.content}$$')
        elif el.type == 'formula_inline':
            lines.append(f'${el.content}$')
        elif el.type == 'hr':
            lines.append('---')
        else:
            lines.append(el.content)
        lines.append('')
    return '\n'.join(lines)


def _resolve_template(template_name: str, template_path: str = None) -> str:
    if template_path:
        p = Path(template_path)
        return str(p if p.is_absolute() else WORKING_DIR / p)
    if template_name in TEMPLATE_MAPPING:
        p = Path(TEMPLATE_MAPPING[template_name])
        return str(p if p.is_absolute() else WORKING_DIR / p)
    raise ValueError(f"未知模板 '{template_name}'。已知: {list(TEMPLATE_MAPPING.keys())}")


# ─── 便捷函数 ──────────────────────────────────────────────────
_renderer = None

def get_renderer() -> DocxSecureRenderer:
    global _renderer
    if _renderer is None:
        _renderer = DocxSecureRenderer()
    return _renderer

def generate_docx(template_name: str, content_markdown: str,
                  template_path: str = None, output_path: str = None) -> dict:
    return get_renderer().generate(template_name, content_markdown, template_path, output_path=output_path)

def modify_and_regenerate(template_name: str, previous_markdown: str,
                          modification_instruction: str, template_path: str = None,
                          output_path: str = None) -> dict:
    return get_renderer().modify_and_regenerate(
        template_name, previous_markdown, modification_instruction, template_path, output_path)

def validate_docx(file_path: str) -> Tuple[bool, Optional[str]]:
    return get_renderer().validate(file_path)


def _fail_result(output_file, markdown, template_name, tracker, error):
    return {
        'success': False, 'fatal': True,
        'message': f'❌ 文档生成失败。渲染异常: {error}',
        'output_path': output_file, 'markdown_snapshot': markdown,
        'template_name': template_name, 'media_tracker': tracker,
    }


# ═══════════════════════════════════════════════════════════════
# 格式审计与自动修正
# ═══════════════════════════════════════════════════════════════

def format_audit_and_fix(docx_path: str, template_path: str) -> str:
    """
    打开生成的 docx 和模板，逐项比对并自动修正格式偏差。

    检查项：
      1. 样式名校验 — Heading 1/2 被误标为 Normal → 修正
      2. 段落属性校验 — 移除与模板样式重复的段落级格式覆盖
      3. 表格边框校验 — 三线表格式：顶线1.5pt + 表头线0.75pt + 底线1.5pt

    返回审计报告字符串。修正失败则返回空字符串。
    """
    try:
        from docx import Document
        from docx.oxml.ns import qn
        from docx.oxml import parse_xml
        from docx.shared import Pt
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        return ""

    try:
        doc = Document(docx_path)
        template = Document(template_path)
    except Exception:
        return ""

    ns_w = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    fixes = {'style_names': 0, 'para_attrs': 0, 'table_borders': 0}
    details = []

    # ── 1. 样式名校验 ──
    heading_map = {1: 'Heading 1', 2: 'Heading 2', 3: 'Heading 3', 4: 'Heading 4'}
    for p in doc.paragraphs:
        pPr = p._element.find(f'{{{ns_w}}}pPr')
        if pPr is None:
            continue
        pStyle = pPr.find(f'{{{ns_w}}}pStyle')
        if pStyle is None:
            continue
        current_style = pStyle.get(f'{{{ns_w}}}val', '')

        # 检测：粗体+大字号的 Normal 段落 → 可能是标题
        runs = p.runs
        if runs and current_style == 'Normal':
            r = runs[0]
            if r.bold and r.font.size and r.font.size >= Pt(14):
                # 可能是 Heading 1
                pStyle.set(f'{{{ns_w}}}val', 'Heading 1')
                fixes['style_names'] += 1
            elif r.bold and r.font.size and r.font.size >= Pt(12):
                pStyle.set(f'{{{ns_w}}}val', 'Heading 2')
                fixes['style_names'] += 1

    # ── 1b. 强制修正样式颜色 + Heading 1 bold ──
    for style_name in ['Title', 'Heading 1', 'Heading 2', 'Heading 3', 'Heading 4', 'Normal']:
        try:
            s = doc.styles[style_name]
            s.font.color.rgb = RGBColor(0, 0, 0)
        except Exception:
            pass
    try:
        h1_style = doc.styles['Heading 1']
        h1_xml = h1_style.element
        rPr = h1_xml.find(f'{{{ns_w}}}rPr')
        if rPr is None:
            rPr = parse_xml(f'<w:rPr {nsdecls("w")} />')
            h1_xml.append(rPr)
        has_b = rPr.find(f'{{{ns_w}}}b') is not None
        if not has_b:
            rPr.append(parse_xml(f'<w:b {nsdecls("w")} />'))
            fixes['style_names'] += 1
    except Exception:
        pass

    if fixes['style_names'] > 0:
        details.append(f"Heading 1 bold ×{fixes['style_names']}")

    # ── 1c. 图表题注样式修正 ──
    caption_fixes = 0
    for p in doc.paragraphs:
        text = p.text.strip()
        if not text:
            continue
        pPr = p._element.find(f'{{{ns_w}}}pPr')
        if pPr is None:
            pPr = parse_xml(f'<w:pPr {nsdecls("w")} />')
            p._element.insert(0, pPr)
        pStyle = pPr.find(f'{{{ns_w}}}pStyle')
        current = pStyle.get(f'{{{ns_w}}}val') if pStyle is not None else 'Normal'

        # 表题：以"表"开头 → Table Caption 样式 + 显式居中
        if text.startswith('表') and 'Table Caption' in [s.name for s in doc.styles]:
            if pStyle is None:
                pStyle = parse_xml(f'<w:pStyle {nsdecls("w")} w:val="Table Caption"/>')
                pPr.append(pStyle)
            else:
                pStyle.set(f'{{{ns_w}}}val', 'Table Caption')
            # 清除段落级对齐和缩进，显式设置居中
            for jc in pPr.findall(f'{{{ns_w}}}jc'): pPr.remove(jc)
            for ind in pPr.findall(f'{{{ns_w}}}ind'): pPr.remove(ind)
            pPr.append(parse_xml(f'<w:jc {nsdecls("w")} w:val="center"/>'))
            caption_fixes += 1

        # 图题：以"图"开头（短段落）→ Caption 样式 + 显式居中
        if text.startswith('图') and len(text) < 80 and 'Caption' in [s.name for s in doc.styles]:
            if pStyle is None:
                pStyle = parse_xml(f'<w:pStyle {nsdecls("w")} w:val="Caption"/>')
                pPr.append(pStyle)
            else:
                pStyle.set(f'{{{ns_w}}}val', 'Caption')
            for jc in pPr.findall(f'{{{ns_w}}}jc'): pPr.remove(jc)
            for ind in pPr.findall(f'{{{ns_w}}}ind'): pPr.remove(ind)
            pPr.append(parse_xml(f'<w:jc {nsdecls("w")} w:val="center"/>'))
            caption_fixes += 1

    fixes['style_names'] += caption_fixes
    if caption_fixes > 0:
        details.append(f"图表题注样式 ×{caption_fixes}")

    # ── 2. 段落属性校验 ──
    sample_count = 0
    for p in doc.paragraphs:
        if sample_count >= 5:
            break
        pPr = p._element.find(f'{{{ns_w}}}pPr')
        if pPr is None:
            continue
        # 检查是否有段落级字体覆盖（w:rPr inside w:pPr）
        pPr_rPr = pPr.find(f'{{{ns_w}}}rPr')
        if pPr_rPr is not None and sample_count < 5:
            pPr.remove(pPr_rPr)
            fixes['para_attrs'] += 1
        # 检查段落级缩进
        ind = pPr.find(f'{{{ns_w}}}ind')
        if ind is not None and sample_count < 3:
            first_line = ind.get(f'{{{ns_w}}}firstLine')
            if first_line:
                # 保留缩进但移除重复定义
                pass
        sample_count += 1

    if fixes['para_attrs'] > 0:
        details.append(f"移除段落级字体覆盖 ×{fixes['para_attrs']}")

    # ── 3. 表格边框校验（固定标准三线表；仅继承模板表头填充）──
    ref_top_sz = "24"; ref_hdr_bot_sz = "12"; ref_bot_sz = "24"; ref_hdr_fill = "auto"
    try:
        tpl_doc = Document(template_path)
        if tpl_doc.tables:
            ref_tbl = tpl_doc.tables[0]
            tcPr0 = ref_tbl.cell(0, 0)._element.find(f'{{{ns_w}}}tcPr')
            if tcPr0 is not None:
                shd = tcPr0.find(f'{{{ns_w}}}shd')
                if shd is not None: ref_hdr_fill = shd.get(f'{{{ns_w}}}fill', 'auto')
    except Exception:
        pass

    for table in doc.tables:
        tbl = table._tbl
        tblPr = tbl.find(f'{{{ns_w}}}tblPr')
        if tblPr is None:
            tblPr = parse_xml(f'<w:tblPr {nsdecls("w")} />')
            tbl.insert(0, tblPr)
        for old_b in tblPr.findall(f'{{{ns_w}}}tblBorders'):
            tblPr.remove(old_b)

        num_rows = len(table.rows)
        if num_rows == 0:
            continue

        for r_idx, row in enumerate(table.rows):
            for cell in row.cells:
                # 标准三线表文字：宋体9pt、全部居中、表头加粗。
                for para in cell.paragraphs:
                    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    para.paragraph_format.first_line_indent = Pt(0)
                    para.paragraph_format.space_after = Pt(0)
                    for run in para.runs:
                        run.font.name = '宋体'
                        run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), '宋体')
                        run.font.size = Pt(9)
                        if r_idx == 0:
                            run.bold = True
                tcPr = cell._element.find(f'{{{ns_w}}}tcPr')
                if tcPr is None:
                    tcPr = parse_xml(f'<w:tcPr {nsdecls("w")} />')
                    cell._element.insert(0, tcPr)
                for old in tcPr.findall(f'{{{ns_w}}}tcBorders'):
                    tcPr.remove(old)

                borders_parts = []
                if r_idx == 0:
                    # 移除渲染器可能写入的残留填充
                    for old_shd in tcPr.findall(f'{{{ns_w}}}shd'):
                        tcPr.remove(old_shd)
                    if ref_hdr_fill != 'auto' and ref_hdr_fill != 'none':
                        tcPr.append(parse_xml(
                            f'<w:shd {nsdecls("w")} w:val="clear" w:color="auto" w:fill="{ref_hdr_fill}"/>'))
                    borders_parts.append(
                        f'<w:top w:val="single" w:sz="{ref_top_sz}" w:space="0" w:color="000000"/>')
                    borders_parts.append(
                        f'<w:bottom w:val="single" w:sz="{ref_hdr_bot_sz}" w:space="0" w:color="000000"/>')
                elif r_idx == num_rows - 1:
                    borders_parts.append(
                        f'<w:bottom w:val="single" w:sz="{ref_bot_sz}" w:space="0" w:color="000000"/>')

                if borders_parts:
                    tcPr.append(parse_xml(
                        f'<w:tcBorders {nsdecls("w")}>{"".join(borders_parts)}</w:tcBorders>'))

        fixes['table_borders'] += 1

    if fixes['table_borders'] > 0:
        details.append(f"三线表修正 ×{fixes['table_borders']}")

    # ── 保存修正 ──
    total = sum(fixes.values())
    if total > 0:
        doc.save(docx_path)
        detail_str = " + ".join(d for d in details if d)
        return f"📋 格式审计完成\n   样式名修正：{fixes['style_names']} 处\n   段落属性修正：{fixes['para_attrs']} 处\n   表格边框修正：{fixes['table_borders']} 处（{detail_str}）"
    else:
        return "📋 格式审计完成：无需修正"


# ═══════════════════════════════════════════════════════════════
# 自检
# ═══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("DOCX Secure Renderer v2 自检\n")
    print(f"  模板映射: {list(TEMPLATE_MAPPING.keys())}")
    for name in TEMPLATE_MAPPING:
        exists = Path(TEMPLATE_MAPPING[name]).exists()
        print(f"    {name}: {TEMPLATE_MAPPING[name]} {'✅' if exists else '❌'}")

    # LaTeX → OMML
    print("\n  公式转换测试:")
    for latex in [r'E=mc^2', r'\frac{a}{b}', r'\int_0^\infty e^{-x^2} dx', r'x_{i,j}^{(t+1)}']:
        try:
            omml = latex_to_omath(latex)
            tag = etree.tostring(omml, encoding='unicode')[:60] if omml is not None else 'None'
            print(f"    ✅ ${latex}$ → {tag}...")
        except Exception as e:
            print(f"    ❌ ${latex}$ → {e}")

    print("\n  ✅ 自检完成")
