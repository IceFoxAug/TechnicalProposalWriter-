"""
Markdown 解析器 v3 — ASCII 安全标记法。
用 __FMLBLOCK_N__ / __FMLINLINE_N__ 替换公式，纯 ASCII，XML/文件系统安全。
"""
import re
from typing import List, Tuple, Optional
from dataclasses import dataclass, field

BLOCK_PFX = "__FMLBLOCK_"
BLOCK_SFX = "__"
INLINE_PFX = "__FMLINLINE_"
INLINE_SFX = "__"


@dataclass
class MDElement:
    type: str
    level: int = 0
    content: str = ""
    meta: dict = field(default_factory=dict)


@dataclass
class MediaTracker:
    images_expected: int = 0
    images_succeeded: int = 0
    images_failed: list = field(default_factory=list)
    formulas_expected: int = 0
    formulas_succeeded: int = 0
    formulas_failed: list = field(default_factory=list)
    @property
    def image_report(self): return f"{self.images_succeeded}/{self.images_expected}"
    @property
    def formula_report(self): return f"{self.formulas_succeeded}/{self.formulas_expected}"
    @property
    def all_ok(self): return (self.images_succeeded == self.images_expected and
                               self.formulas_succeeded == self.formulas_expected)


def parse_markdown(md_text: str, tracker: "MediaTracker" = None) -> List[MDElement]:
    """
    解析 Markdown。分两阶段：
    1. 用 ASCII 标记替换 $$...$$ / $...$ / ![...](...)
    2. 按行解析标准 MD 元素
    """
    # ── 阶段1：替换 ──
    block_f = {}   # idx -> latex
    inline_f = {}  # idx -> latex

    def _store_block(m):
        idx = len(block_f)
        block_f[idx] = m.group(1).strip()
        return f'{BLOCK_PFX}{idx}{BLOCK_SFX}'

    def _store_inline(m):
        idx = len(inline_f)
        inline_f[idx] = m.group(1).strip()
        return f'{INLINE_PFX}{idx}{INLINE_SFX}'

    text = re.sub(r'\$\$\s*(.+?)\s*\$\$', _store_block, md_text, flags=re.DOTALL)
    text = re.sub(r'\$(.+?)\$', _store_inline, text)

    def _restore_inline(raw):
        """恢复段落或表格中的行内公式，并登记每个公式。"""
        for idx, latex in inline_f.items():
            marker = f'{INLINE_PFX}{idx}{INLINE_SFX}'
            if marker in raw:
                count = raw.count(marker)
                if tracker:
                    tracker.formulas_expected += count
                raw = raw.replace(marker, f'__FML__{latex}__ENDFML__')
        return raw

    # ── 阶段2：按行解析 ──
    elements = []
    lines = text.split('\n')
    i = 0

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        # ``` 代码块
        if stripped.startswith('```'):
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith('```'):
                code_lines.append(lines[i])
                i += 1
            i += 1
            elements.append(MDElement('code', content='\n'.join(code_lines)))
            continue

        # --- 水平线
        if re.match(r'^[-\*_]{3,}\s*$', stripped):
            elements.append(MDElement('hr'))
            i += 1
            continue

        # ![alt](url)
        img = re.match(r'^!\[([^\]]*)\]\(([^\)]+)\)\s*$', stripped)
        if img:
            if tracker: tracker.images_expected += 1
            elements.append(MDElement('image', content=img.group(1), meta={'url': img.group(2)}))
            i += 1
            continue

        # __FMLBLOCK_N__
        bm = re.match(r'^__FMLBLOCK_(\d+)__\s*$', stripped)
        if bm:
            idx = int(bm.group(1))
            if idx in block_f:
                if tracker: tracker.formulas_expected += 1
                elements.append(MDElement('formula_block', content=block_f[idx]))
            i += 1
            continue

        # # 标题
        h = re.match(r'^(#{1,6})\s+(.+)$', stripped)
        if h:
            elements.append(MDElement('heading', level=min(len(h.group(1)), 4),
                           content=h.group(2).strip()))
            i += 1
            continue

        # | 表格
        if '|' in stripped and i + 1 < len(lines):
            sep = lines[i + 1].strip()
            if re.match(r'^\|?[\s\-:|]+\|?$', sep):
                tlines = [stripped, sep]
                i += 2
                while i < len(lines) and '|' in lines[i]:
                    tlines.append(lines[i].strip())
                    i += 1
                elements.append(MDElement('table', content=_restore_inline('\n'.join(tlines))))
                continue

        # - 无序列表
        ul = re.match(r'^[-*+]\s+(.+)$', stripped)
        if ul:
            elements.append(MDElement('list', content=ul.group(1), meta={'ordered': False}))
            i += 1
            continue

        # 1. 有序列表
        ol = re.match(r'^\d+[\.\)]\s+(.+)$', stripped)
        if ol:
            elements.append(MDElement('list', content=ol.group(1), meta={'ordered': True}))
            i += 1
            continue

        # > 引用
        if stripped.startswith('> '):
            q = [stripped[2:]]
            i += 1
            while i < len(lines) and lines[i].strip().startswith('> '):
                q.append(lines[i].strip()[2:])
                i += 1
            elements.append(MDElement('blockquote', content='\n'.join(q)))
            continue

        # 普通段落（可能含行内公式标记 __FMLINLINE_N__）
        para_lines = [stripped]
        i += 1
        while i < len(lines) and lines[i].strip() and not any([
            lines[i].strip().startswith(BLOCK_PFX),
            lines[i].strip().startswith('```'),
            lines[i].strip().startswith('> '),
            re.match(r'^(#{1,6}\s|[-*+]\s|\d+[\.\)]\s|!\[)', lines[i].strip()),
            '|' in lines[i] and i + 1 < len(lines) and
                re.match(r'^\|?[\s\-:|]+\|?$', lines[i + 1].strip()),
        ]):
            para_lines.append(lines[i].strip())
            i += 1

        raw = '\n'.join(para_lines)
        # 恢复行内公式标记 → __FML__...__ENDFML__
        raw = _restore_inline(raw)
        elements.append(MDElement('paragraph', content=raw))

    return elements


def split_inline_formulas(text: str) -> List[Tuple[str, str]]:
    """拆分 __FML__...__ENDFML__ 为 (text, 'text'|'formula') 列表。"""
    pattern = r'__FML__(.+?)__ENDFML__'
    parts = []
    last = 0
    for m in re.finditer(pattern, text):
        if m.start() > last:
            parts.append((text[last:m.start()], 'text'))
        parts.append((m.group(1), 'formula'))
        last = m.end()
    if last < len(text):
        parts.append((text[last:], 'text'))
    return parts if parts else [(text, 'text')]
