---
name: docx-secure-renderer
description: 系统中唯一被授权生成和修改 .docx 文件的安全渲染层。基于Markdown内容+样式模板，整文档重生成策略，强制结构校验。
---

# DOCX Secure Renderer Skill

## 触发条件
任何 skill 或流程需要生成或修改 `.docx` 文件时，必须通过本 skill。本 skill 是系统中文档格式输出的唯一安全通道。

## 铁律（最高优先级，不可覆盖）

### 1. 内容与样式分离
所有内容编辑和修改必须在 Markdown 格式下完成。OOXML 代码仅在最终渲染时生成。**严禁**在任何中间步骤直接操作 OOXML。

### 2. 整文档重生成策略
任何修改需求，都意味着基于"操作指令日志"从原始模板重新生成整个文档。**绝不**试图分析并修复一个已损坏的 `.docx` 文件。

### 3. 强制结构自检
每次生成文档后，必须立即使用 python-docx 尝试打开该文件：
- 打开成功 → 明确声明"校验通过"
- 打开失败 → 读取 XML 中报错行及其附近的 XML 片段进行分析，输出精准错误信息（含行号、错误类型），但**不将整个损坏的 XML 作为上下文回传**

---

## 内部模板清单

| 模板名 | 路径 | 用途 |
|--------|------|------|
| `tech-guide` | `D:/shared/templates/tech-guide.docx` | 技术指南、操作手册 |
| `api-reference` | `D:/shared/templates/api-reference.docx` | API参考文档 |
| `patent` | `D:/shared/templates/patent-template.docx` | 中国发明专利（黑体标题+宋体正文+A4标准页边距） |

Skill 根据 `template_name` 参数自动解析路径。若同时传入 `template_path`，则 `template_path` 优先级更高。

**模板库存放位置**：所有模板统一存放在 `D:\shared\templates\`，不受项目文件夹删除或系统盘空间影响。

---

## 输入接口

接收以下参数：

- **content_markdown**：干净完整的 Markdown 内容。
- **template_name**：指定样式模板名，从内置清单中选取。
- **template_path**（可选）：直接指定模板文件路径。优先级高于 `template_name`。
- **recipe_json**（可选）：操作指令日志。若提供，则按此日志从模板重新生成。

---

## 核心处理能力

### generate_docx(template_path, markdown_content)
基于模板样式，将 Markdown 内容转换为 Word 文档。

处理流程：
1. 解析 `template_path`，用 python-docx 打开模板获取样式引用
2. 将 Markdown 解析为结构化内容块（标题、段落、代码块、表格、列表、图片）
3. 按模板预设样式，将内容块逐块写入新文档
4. 自动处理图片下载与嵌入（支持本地路径和网络 URL）
5. 保存文档到输出路径

### validate_docx(file_path)
用 python-docx 尝试打开文件，返回 `(is_valid, error_info)`。
- `is_valid`: bool
- `error_info`: 失败时包含精准的 XML 行号和错误描述

### Markdown 到 OOXML 映射规则

| Markdown 元素 | 对应样式 |
|---------------|----------|
| `# 标题` | Heading 1 |
| `## 标题` | Heading 2 |
| `### 标题` | Heading 3 |
| `#### 标题` | Heading 4 |
| 普通段落 | Normal（正文） |
| ` ``` 代码 ``` ` | CodeBlock |
| `` `内联代码` `` | InlineCode (字符样式) |
| `- 列表项` | BulletList |
| `> 引用` | NoteBlock |
| 表格 | 自动应用表格边框格式 |
| `![alt](url)` | 下载并嵌入图片 |
| `**粗体**` | bold |
| `*斜体*` | italic |

### 特殊模板样式

**tech-guide 模板**：CodeBlock、InlineCode、BulletList、NoteBlock

**api-reference 模板**：CodeBlock、InlineCode、EndpointName（端点/方法名高亮）、HTTPMethod（HTTP方法标签）、ParamTable（参数表格）、BulletList、ParamName（参数名高亮）、CodeExample（代码示例区域）

---

## 输出规范

**成功时**：
```
✅ 文档生成成功。文件路径：[路径]。结构校验：通过。
```

**失败时**：
```
❌ 文档生成失败。错误信息：[精准XML错误]。建议：请回滚到上一个完好状态，基于操作指令日志从原始模板重新生成。
```

---

## 调用协议

其他 Skill 只需在指令中写：

```
调用 docx-secure-renderer，模板用 [模板名]，内容如下：
[Markdown内容]
```

即可完成文档生成。

---

## 实现参考

核心实现位于同目录下的 `renderer.py`，由本 SKILL.md 加载时自动引用。

### 使用方式

```python
import sys
sys.path.insert(0, r"C:\Users\Andre Fan\.claude\skills\docx-secure-renderer")
from renderer import DocxSecureRenderer

renderer = DocxSecureRenderer()
result = renderer.generate(
    template_name="tech-guide",
    content_markdown="# 测试文档\n\n这是一个测试段落。",
    output_path="./output.docx"
)
print(result)
# 或手动校验
is_valid, error_info = renderer.validate("./output.docx")
```

---

## 协作关系（被依赖方）

本 skill 是系统中 `.docx` 操作的**基础设施层**，被以下 skill 依赖：

| 依赖方 Skill | 依赖方式 | 说明 |
|-------------|---------|------|
| `patent-writer` | 模板解析 + 校验 | 通过 `resolve_template_path("patent")` 获取默认模板路径；build 后调用 `validate_docx()` |
| `technical-proposal-writer` | 仅校验 | build 后调用 `validate_docx()` 进行结构自检 |

### 为上游 skill 暴露的公开 API

```python
import sys
sys.path.insert(0, r"C:\Users\Andre Fan\.claude\skills\docx-secure-renderer")
from renderer import resolve_template_path, validate_docx, TEMPLATE_MAPPING

# 1. 解析模板路径（按名称）
template_path = resolve_template_path(template_name="patent")

# 2. 列出所有已注册模板
print(TEMPLATE_MAPPING)  # {"tech-guide": "...", "api-reference": "...", "patent": "..."}

# 3. 校验任意 docx 文件
is_valid, error_info = validate_docx("./output.docx")
if not is_valid:
    print(f"❌ 校验失败: {error_info}")
```

**注意**：`generate_docx()` 是 Markdown→docx 的完整渲染管线，适用于纯文本+图片的文档生成。对于需要 OMML 公式的复杂文档（专利、标书），上游 skill 使用各自的专用 builder（`PatentBuilder`、`writer.py`），仅调用本 skill 的模板解析和校验功能。
