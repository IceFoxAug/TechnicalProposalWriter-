---
name: omml-formula-writer
description: |
  OMML（Office Math Markup Language）公式写入引擎。将类 LaTeX 文本（_下标、^上标、希腊字母）编译为 Word OMML 数学公式，
  支持行间（居中+编号）和行内两种模式。自动处理三线表边框、学术插图标准。
  适用于技术论文、学术标书、项目专利等需排版的 docx 文档。
metadata:
  version: "1.1.0"
  lessons_from: "液冷数据中心DR策略论文 v1.0→v1.4 实战迭代"
---

# OMML Formula Writer Skill

## 触发条件

用户需要以下场景时调用此 skill：
- 在 docx 中写入带上下标、希腊字母的数学公式
- 生成技术论文/学术文档中需要 OMML 公式排版
- 用户提到"OMML公式""排版公式""数学公式写入Word"
- 被其他 skill 依赖调用（patent-writer、technical-proposal-writer）

**关键词**："OMML公式" "公式排版" "写入公式到docx" "数学公式Word" "omml"

---

## 核心架构

```
omml_helper.py (基础引擎，位于 C:\Users\Andre Fan\.claude\skills\)
  ├── OMMLEq 类          → build_formula(tokens) 生成 OMML XML
  ├── parse_formula()     → 基础公式解析（_下标）
  ├── split_inline_math() → 文本/数学片段分割
  └── _GREEK_CHARS, _MATH_OPS → 数学检测字符集

formula_parser.py (增强解析器，位于 ...\skills\patent-writer\)
  ├── parse_formula_enhanced()  → 完整解析（_ + ^ + _{...} + ^{...} + sqrt）
  ├── round_trip_validate()     → 往返自测
  └── deep_structure_validate() → 结构完整性校验

formula_validate.py (后置校验，位于 ...\skills\patent-writer\)
  ├── validate_formulas() → 检查空下标/上标残留/CJK入数学区
  └── print_validation()  → 打印校验报告
```

### 调用方式

```python
import sys
sys.path.insert(0, r"C:\Users\Andre Fan\.claude\skills")
sys.path.insert(0, r"C:\Users\Andre Fan\.claude\skills\patent-writer")

from omml_helper import OMMLEq
from formula_parser import parse_formula_enhanced

builder = OMMLEq()
tokens = parse_formula_enhanced("P_ser(t) = P_ser,0 + kappa_ser * [f(t)]^3")
omath = builder.build_formula(tokens)
```

---

## ⚠️ 核心规则（实战教训，最高优先级）

### 规则 1：正文段落严禁内联 OMML

**问题**：`split_inline_math()` 将 `T_supply`、`C_th,L` 等含下划线的变量名误判为数学片段，拆分为孤立 OMML 片段嵌入中文正文，导致排版混乱（碎片化 OMML 与中文无法正确对齐）。

**根因**：`_has_math()` → `split_inline_math()` 检测链过于激进。任何含 `_` 或希腊字母的文本都被拆分，产生大量 2~3 字符的 OMML 片段。

**正确做法**：
```python
# ❌ 错误：正文使用内联 OMML
def body(self, text):
    if self._has_math(text):
        segments = split_inline_math(text)
        for seg_text, is_math in segments:
            if is_math:
                omath = builder.build_formula(parse_formula_enhanced(seg_text))
                p._element.append(omath)  # 碎片化 OMML！

# ✅ 正确：正文全部纯文本
def body(self, text):
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.74)
    r = p.add_run(text)  # 纯文本，宋体
```

**适用范围**：所有含中文的学术文档正文。OMML **仅用于行间显示公式**（居中+编号）。

### 规则 2：公式"式中："注释必须独立成段

**问题**：将变量说明（"式中：P_ser,0为服务器空闲状态基础功耗；..."）作为公式方法的第二个参数嵌入公式段落，导致长文本在公式行内折行，与公式编号和OMML排版冲突。

**正确做法**：
```python
# ❌ 错误：长注释嵌入公式段落
pw.formula("P_ser(t) = P_ser,0 + kappa_ser * [f(t)]^3 * u(t)",
           "式中：P_ser,0为服务器空闲状态基础功耗；kappa_ser为...")  # 过长！

# ✅ 正确：公式与注释分离
pw.formula("P_ser(t) = P_ser,0 + kappa_ser * [f(t)]^3 * u(t)")
pw.body_where("式中：P_ser,0为服务器空闲状态基础功耗；kappa_ser为服务器功耗系数；"
              "f(t)为处理器频率归一化值(0≤f≤1)；u(t)为CPU利用率。")
```

其中 `body_where()` 为无首行缩进的正文段落：
```python
def body_where(self, text):
    p = self.doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0)  # 不缩进
    r = p.add_run(text); r.font.name = '宋体'; r.font.size = Pt(10.5)
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
```

**判断标准**：若"式中："文本超过 40 个汉字，**必须**独立成段。

### 规则 3：仅行间公式使用 OMML

OMML 的适用范围严格限定为：

| 类型 | 是否OMML | 格式 |
|------|----------|------|
| 行间显示公式（带编号） | ✅ 是 | OMML居中 + Tab右对齐编号 `(1)` |
| 正文中变量名（`P_ser`） | ❌ 否 | 纯文本宋体 |
| 正文中物理量（`T_supply`） | ❌ 否 | 纯文本宋体 |
| 正文中单位（`kW·h/°C`） | ❌ 否 | 纯文本宋体 |
| 摘要/关键词 | ❌ 否 | 纯文本 |

### 规则 4：三线表边框规范

使用**单元格级** `tcBorders`，禁止表格级 `insideH`/`insideV`：

```python
# 表格级：全部边框 none
tblB = OxmlElement('w:tblBorders')
for bn in ['top', 'left', 'bottom', 'right', 'insideH', 'insideV']:
    b = OxmlElement('w:' + bn)
    b.set(qn('w:val'), 'none'); b.set(qn('w:sz'), '0')
    tblB.append(b)

# 单元格级：仅三处有边框
# 顶线：第一行每格 tcBorders → top: sz=12 (1.5pt)
# 表头线：第一行每格 tcBorders → bottom: sz=6 (0.75pt)
# 底线：最后一行每格 tcBorders → bottom: sz=12 (1.5pt)
```

| 边框 | 线宽(pt) | OOXML sz值 | 位置 |
|------|---------|-----------|------|
| 顶线 | 1.5 | 12 | 第一行 top |
| 表头线 | 0.75 | 6 | 第一行 bottom |
| 底线 | 1.5 | 12 | 最后一行 bottom |

> 注：OOXML `w:sz` 单位为 1/8 pt。1.5pt = 12/8，0.75pt = 6/8。

### 规则 5：学术插图标准

| 参数 | 值 | 说明 |
|------|-----|------|
| DPI | **300** | 印刷级清晰度 |
| 字号 | **10pt** | 与正文题注一致 |
| `bbox_inches` | `'tight'` | 自动裁边 |
| `pad_inches` | `0.1` | 最小白边 |
| 画布 | 内容撑满 | 调整 `figsize` + `xlim/ylim` 使节点覆盖整个画布 |
| 图内标题 | **禁止** | `set_title`/`suptitle` 移除，题注仅在 docx 中 |

**标准画布尺寸参考**：
- 竖向流程图：`figsize=(11, 9)` — 11节点均匀分布
- 横向对比图：`figsize=(9, 4)` — 多子图并排
- 曲线图：`figsize=(8, 4)` — 单图

**流程图学术风格指南**：
- 配色：深蓝灰 `#2C3E50` / 中蓝 `#2471A3` / 浅蓝 `#5DADE2`
- 节点分级：首尾节点（粗框） > 关键节点 > 普通节点（细框）
- 层级背景：浅色半透明横带区分逻辑阶段
- 阶段标签：融入色带内，灰蓝小字竖排（`#5D6D7E`, 8.5pt, rotation=90）
- 箭头：灰色 `#85929E`，`lw=1.5`
- 节点间留 0.4~0.5 y 单位间距

### 规则 6：公式源码中禁止字面空格

**问题**：公式源码中的空格（如 `= `、` + `、` · `、` − `）被 `parse_formula_enhanced()` 原样保留在 OMML 的 `m:t` 元素中，Word 数学引擎将其渲染为可见空格，导致行间公式出现多余间距。

**根因**：`parse_formula_enhanced()` → Phase 1 逐字符处理 → 空格字符落入 `text` 类型 token → 传递至 `parse_formula()` → 生成 `m:t` 元素时保留空格 → Word 在公式内渲染字面空格。

**正确做法**：公式源码中去除所有空格。OMML 数学引擎自动为 `+`、`−`、`·`、`×`、`=`、`≥`、`≤`、`/` 等运算符添加正确间距。

```python
# ❌ 错误：运算符周围有空格
pw.formula("P_ser(t) = P_ser,0 + kappa_ser · [f(t)]^3 · u(t)")

# ✅ 正确：去除全部空格
pw.formula("P_ser(t)=P_ser,0+kappa_ser·[f(t)]^3·u(t)")
```

**验证方法**：生成 docx 后检查 `m:t` 元素是否包含前导/尾随空格：
```python
for mt in omath.iter('{http://...}t'):
    if mt.text and (mt.text.startswith(' ') or mt.text.endswith(' ')):
        # 存在空格问题
```

### 规则 7：逗号分隔下标须完整识别

**问题**：`parse_formula_enhanced()` 中简单下标扫描（非 `_{...}` 形式）只接受 `isalnum()` 和 `_`，逗号被排除。`P_ser,0` 只取到 `ser` 为下标，`,0` 变为孤立文本，导致公式中出现"半个下标"的编译错误。

**根因**：`formula_parser.py` 第 206 行和第 230 行：
```python
# ❌ 旧代码：逗号不被接受
while i < n and (text[i].isalnum() or text[i] == '_'):
```

**修复**：`formula_parser.py` 两处下标扫描条件均已改为：
```python
# ✅ 修复后：同时接受逗号
while i < n and (text[i].isalnum() or text[i] in '_,'):
```

**受影响的下标模式**：
| 写法 | 预期下标 | 修复前 | 修复后 |
|------|---------|--------|--------|
| `P_ser,0` | `ser,0` | `ser`（,0 丢失） | `ser,0` ✅ |
| `C_th,L` | `th,L` | `th`（,L 丢失） | `th,L` ✅ |
| `T_DR,eff` | `DR,eff` | `DR`（,eff 丢失） | `DR,eff` ✅ |
| `T_DR,eff,A` | `DR,eff,A` | `DR`（,eff,A 丢失） | `DR,eff,A` ✅ |
| `P_ACS,max` | `ACS,max` | `ACS`（,max 丢失） | `ACS,max` ✅ |

**注意**：若需其他分隔符（如 `.`），可使用 `_{...}` 花括号显式写法（如 `x_{a.b}`），该路径走括号匹配，不受此限制。

### 规则 8：行内 OMML 的正确实现方式

**问题**：此前规则 1 要求"正文严禁内联 OMML"，但学术论文的"式中："段落中大量变量名（`P_ser,0`、`C_th,L` 等）以纯文本形式出现，排版效果不如 OMML 渲染。

**折中方案**：规则 1 的禁令源于 `split_inline_math()` 对含 `_` 文本的误判。采用 `$...$` 分隔符显式标记数学片段，可安全实现行内 OMML：

```python
def _render_mixed_paragraph(self, p, text):
    """将包含 $...$ 的文本渲染为文本run+OMML交替的段落。"""
    parts = re.split(r'\$([^$]+)\$', text)
    for i, part in enumerate(parts):
        if not part:
            continue
        if i % 2 == 0:
            # Regular text run
            r = p.add_run(part)
            r.font.name = '宋体'; r.font.size = Pt(10.5)
            r._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        else:
            # Inline OMML math — m:oMath as child of w:p
            tokens = parse_formula_enhanced(part)
            omath = self.builder.build_formula(tokens)
            self._style_omath(omath)  # sz=21 (10.5pt)
            p._element.append(omath)
```

**关键点**：
- `m:oMath` 元素直接作为 `w:p` 的子元素，与 `w:r` 文本 run 交替排列
- **严禁**使用 `m:oMathPara`（那是行间公式容器）
- 行内数学使用与正文相同的字号（10.5pt = sz 21）
- `$...$` 分隔符不进入最终文档

**适用范围对比**：
| 场景 | 方法 | 说明 |
|------|------|------|
| "式中："段落变量定义 | `body_where_math("$P_ser,0$为空闲功耗")` | ✅ 行内 OMML |
| 正文叙述中提及变量 | `body("供液温度T_supply受...")` | ✅ 纯文本即可 |
| 行间显示公式 | `formula("推导")` | ✅ 仅行间公式 |
| 自动拆分检测 | `split_inline_math()` | ❌ 永远禁用 |

---

## 公式语法

| 写法 | OMML效果 | 示例 |
|------|---------|------|
| `C_inv` | C 带 inv 下标 | `P_ser` → P_ser |
| `Q^T` | Q 带 T 上标 | `f^3` → f³ |
| `alpha_k^(t+1)` | α 带 k 下标和 (t+1) 上标 | 组合 sub+sup |
| `x^{expr}` | x 带 expr 上标（花括号） | `max^{2}` |
| `max_{i,j}` | max 带 i,j 下标 | `max_{i,j}` |
| `sqrt(d)` | √d 根号 | `sqrt(d)` → √d |
| `Sum[i=1..N]` | Σ[i=1..N] | 自动转 Unicode Σ |
| `α β γ δ ε η λ μ τ σ ρ Σ Π` | 希腊字母 | Unicode 直用或英文名自动转换 |

## 显示公式实现模板

```python
def formula(self, math_text):
    """行间OMML公式：居中 + 编号右对齐"""
    self.formula_idx += 1
    eq_num = '(%d)' % self.formula_idx

    tokens = parse_formula_enhanced(math_text)

    p = self.doc.add_paragraph()
    pPr = p._element.get_or_add_pPr()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent = Cm(0)

    # 制表位：居中(公式) + 右对齐(编号)
    tabs = OxmlElement('w:tabs')
    ct = OxmlElement('w:tab'); ct.set(qn('w:val'), 'center'); ct.set(qn('w:pos'), '4536')
    rt = OxmlElement('w:tab'); rt.set(qn('w:val'), 'right'); rt.set(qn('w:pos'), '9072')
    tabs.append(ct); tabs.append(rt); pPr.append(tabs)

    # Tab → OMML → Tab → 编号
    tb = OxmlElement('w:r'); tc = OxmlElement('w:tab'); tb.append(tc)
    p._element.append(tb)

    omath = self.builder.build_formula(tokens)
    self._style_omath(omath)  # Cambria Math 10.5pt
    p._element.append(omath)

    ta = OxmlElement('w:r'); tc2 = OxmlElement('w:tab'); ta.append(tc2)
    p._element.append(ta)

    er = OxmlElement('w:r')
    et = OxmlElement('w:t'); et.text = eq_num; et.set(qn('xml:space'), 'preserve')
    er.append(et)
    p._element.append(er)
```

---

## 协作关系

### 被依赖关系

| 父 Skill | 调用场景 | 公式类型 |
|----------|---------|---------|
| `patent-writer` | 中国发明专利中的公式 | 行间 OMML（居中+编号）+ 行内 OMML（段落中数学符号） |
| `technical-proposal-writer` | 技术标书中的公式 | OMML 或 MathType 格式，编号依模板体系 |
| 学术/技术文档直接写作 | 论文、报告中的公式 | OMML 行间公式（本文所述全部规则） |

### 调用协议

父 skill 调用本 skill 时必须：
1. 设置 `sys.path` 指向 skills 目录和 patent-writer 子目录
2. **遵守规则1**：正文不使用内联 OMML
3. **遵守规则2**：长"式中："独立成段
4. 行间公式用 `parse_formula_enhanced()` + `OMMLEq.build_formula()`
5. 生成后运行 `formula_validate.validate_formulas()` 校验

### 不负责

- LaTeX → OMML 批量转换（那是 pandoc 的职责）
- PPT 中的公式（那是 MathType / PPT 公式编辑器的职责）
- PDF 中的公式渲染（那是 LaTeX / MathJax 的职责）

---

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.1.0 | 2026-06-25 | v1.4润色实战：新增规则6（公式源码禁空格）、规则7（逗号下标完整识别+修复formula_parser.py）、规则8（行内OMML正确实现方式$...$） |
| 1.0.0 | 2026-06-24 | 从 patent-writer 独立；收录液冷数据中心DR论文 v1.0→v1.3 全部排版教训 |

## 相关代码文件

| 文件 | 路径 | 角色 |
|------|------|------|
| `omml_helper.py` | `C:\Users\Andre Fan\.claude\skills\` | OMML XML 构建器（OMMLEq 类） |
| `formula_parser.py` | `...\skills\patent-writer\` | 增强公式解析器（parse_formula_enhanced） |
| `formula_validate.py` | `...\skills\patent-writer\` | OMML 后置校验 |
| `patent_builder.py` | `...\skills\patent-writer\` | PatentBuilder 参考实现（三线表、OMML公式） |
