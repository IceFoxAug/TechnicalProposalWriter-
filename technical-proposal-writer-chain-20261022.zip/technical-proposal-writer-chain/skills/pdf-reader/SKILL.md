---
name: pdf-reader
description: 从PDF提取文本内容，支持文字型PDF、CID编码PDF、扫描件PDF。使用pdfplumber→PyMuPDF→PyPDF2→OCR策略链。
---

# PDF Reader Skill

## 触发条件
用户需要从PDF中提取文本内容时使用，支持文字型PDF、CID编码PDF、扫描件PDF。

**被依赖关系**：本 skill 被 `technical-proposal-writer` 依赖。当 technical-proposal-writer 调用本 skill 时，会传入多个 PDF 文件路径，需逐个解析并返回完整文本。

## 输入
PDF文件（单个或多个）

---

## PDF读取规则

按以下策略链依次尝试，成功即停止：

### 策略一：pdfplumber 提取（首选，中文编码支持最好）
```python
import pdfplumber
with pdfplumber.open("文件.pdf") as pdf:
    text = "\n".join([page.extract_text() or "" for page in pdf.pages])
```

### 策略二：PyMuPDF(fitz) 提取（CID有映射表时可自动解码）
```python
import fitz
doc = fitz.open("文件.pdf")
text = "\n".join([page.get_text() for page in doc])
```

### 策略三：PyPDF2 提取（兜底）
```python
from PyPDF2 import PdfReader
reader = PdfReader("文件.pdf")
text = "\n".join([page.extract_text() or "" for page in reader.pages])
```

### 策略四：扫描件/CID无映射表检测
如果以上三种方式提取文本均空，或有效字符占比小于5%：
- 用 PyMuPDF 检查页面构成（get_images、get_text("blocks")）
- 大量图片+极少量文本块 → 扫描件
- 有文本块但全是乱码/重复字符 → CID无映射表
- 进入策略五

### 策略五：OCR处理

#### 5.1 先判断文档语言
- 优先用策略一至三中提取到的任何有效文字片段判断
- 中文为主 → ocr_lang='chi_sim+eng'
- 英文为主 → ocr_lang='eng'
- 中英混合 → ocr_lang='chi_sim+eng'
- 其他语言或无法判断 → ocr_lang='eng'，并提示用户可指定语言

#### 5.2 执行OCR
```python
import pytesseract
from pdf2image import convert_from_path

# tesseract固定路径
pytesseract.pytesseract.tesseract_cmd = r'D:\Program Files\Tesseract-OCR\tesseract.exe'

# 检查语言包
langs = pytesseract.get_languages()
if ocr_lang not in langs:
    print(f"警告：未找到语言包 {ocr_lang}，降级为 eng")
    ocr_lang = "eng"

# 执行OCR
images = convert_from_path("文件.pdf", dpi=300)
text = ""
for i, img in enumerate(images):
    page_text = pytesseract.image_to_string(img, lang=ocr_lang)
    text += f"\n--- 第{i+1}页 ---\n{page_text}"
```

前置依赖：
- pip install pytesseract pdf2image Pillow
- Tesseract已安装于 D:\Program Files\Tesseract-OCR
- OCR后提示用户结果可能存在少量错字

### 策略六：不可提取
OCR也失败时，标注该文献"文本不可提取"，仅用文件名、年份等元数据。

---

## 提取后质量检查
- 中文字符占比小于5%且文件名含中文 → 尝试下一策略
- 文本长度小于50字符 → 标记异常，尝试下一策略
- 连续10个以上重复字符 → CID解码失败，转OCR
- OCR后字符占比与语言判断矛盾 → 提示用户检查语言设置

---

## 输出
提取的完整文本内容。如部分文献无法提取，说明原因。
