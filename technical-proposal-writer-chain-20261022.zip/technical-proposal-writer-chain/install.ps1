# 技术标书写作技能包安装脚本
# 默认演练模式（只打印计划，不改动磁盘）；加 -Apply 才真正复制。

param(
    [switch]$Apply
)

$ErrorActionPreference = "Stop"

$Source   = Join-Path $PSScriptRoot "skills"
$Target   = Join-Path $env:USERPROFILE ".claude\skills"
$Stamp    = Get-Date -Format "yyyyMMdd-HHmmss"
$OldPath  = 'C:\Users\Andre Fan\.claude\skills'

if (-not (Test-Path $Source)) {
    throw "找不到源目录：$Source（请在解压后的包根目录运行本脚本）"
}

Write-Host "源目录 : $Source"
Write-Host "目标目录: $Target"
Write-Host ("模式   : " + $(if ($Apply) { "执行（-Apply）" } else { "演练（不改动，加 -Apply 执行）" }))
Write-Host ""

$Items = @(
    @{ Path = "writer.py";                          IsDir = $false },
    @{ Path = "omml_helper.py";                     IsDir = $false },
    @{ Path = "technical-proposal-writer";          IsDir = $true  },
    @{ Path = "pdf-reader";                         IsDir = $true  },
    @{ Path = "omml-formula-writer";                IsDir = $true  },
    @{ Path = "docx-secure-renderer";               IsDir = $true  },
    @{ Path = "patent-writer\formula_parser.py";    IsDir = $false }
)

foreach ($item in $Items) {
    $src = Join-Path $Source $item.Path
    $dst = Join-Path $Target $item.Path

    if (-not (Test-Path $src)) {
        Write-Host "[缺失] $src" -ForegroundColor Yellow
        continue
    }

    if (Test-Path $dst) {
        $backup = "$dst.bak-$Stamp"
        Write-Host "[备份] $dst -> $backup"
        if ($Apply) { Move-Item -LiteralPath $dst -Destination $backup }
    }

    Write-Host "[复制] $src -> $dst"
    if (-not $Apply) { continue }

    $parent = Split-Path $dst -Parent
    if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }

    if ($item.IsDir) {
        Copy-Item -Path $src -Destination $dst -Recurse -Force
    } else {
        Copy-Item -Path $src -Destination $dst -Force
    }

    # 改写复制的副本中的硬编码技能根路径（原件不动）
    if ($dst.EndsWith(".md") -or $dst.EndsWith(".py")) {
        $text = Get-Content -LiteralPath $dst -Raw
        if ($text.Contains($OldPath)) {
            $text.Replace($OldPath, $Target) | Set-Content -LiteralPath $dst -NoNewline -Encoding UTF8
            Write-Host "       [改写路径] $dst"
        }
    } elseif ($item.IsDir) {
        Get-ChildItem -LiteralPath $dst -Recurse -Include *.md, *.py | ForEach-Object {
            $text = Get-Content -LiteralPath $_.FullName -Raw
            if ($text.Contains($OldPath)) {
                $text.Replace($OldPath, $Target) | Set-Content -LiteralPath $_.FullName -NoNewline -Encoding UTF8
                Write-Host "       [改写路径] $($_.FullName)"
            }
        }
    }
}

Write-Host ""
if ($Apply) {
    Write-Host "安装完成。下一步：python check_env.py 自检，并在 CLAUDE.md 中加入注册片段。" -ForegroundColor Green
} else {
    Write-Host "演练结束，未改动任何文件。确认无误后运行： .\install.ps1 -Apply" -ForegroundColor Cyan
}
