# -*- coding: utf-8 -*-
"""技术标书写作技能包自检（只读，不修改任何文件）。

用法：python check_env.py
"""

import importlib
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent
SKILLS = ROOT / "skills"

EXPECTED = [
    "skills/writer.py",
    "skills/omml_helper.py",
    "skills/technical-proposal-writer/SKILL.md",
    "skills/pdf-reader/SKILL.md",
    "skills/omml-formula-writer/SKILL.md",
    "skills/docx-secure-renderer/SKILL.md",
    "skills/docx-secure-renderer/renderer.py",
    "skills/docx-secure-renderer/md_parser.py",
    "skills/patent-writer/formula_parser.py",
]

REQUIRED_PKGS = [
    ("docx", "python-docx"),
    ("lxml", "lxml"),
    ("PIL", "Pillow"),
]
OPTIONAL_PKGS = [
    ("pdfplumber", "pdfplumber"),
    ("fitz", "PyMuPDF"),
    ("pypdf", "pypdf"),
    ("pytesseract", "pytesseract"),
    ("pdf2image", "pdf2image"),
    ("latex2mathml", "latex2mathml"),
    ("matplotlib", "matplotlib"),
]

fail = 0


def section(title):
    print(f"\n{'=' * 60}\n{title}\n{'=' * 60}")


section("1. 文件完整性")
for rel in EXPECTED:
    p = ROOT / rel
    if p.is_file():
        print(f"  [OK]   {rel}  ({p.stat().st_size:,} bytes)")
    else:
        print(f"  [缺失] {rel}")
        fail += 1

section("2. Python 依赖")
for mod, pkg in REQUIRED_PKGS:
    try:
        m = importlib.import_module(mod)
        ver = getattr(m, "__version__", "")
        print(f"  [OK]   {pkg:<16} {ver}")
    except Exception as exc:
        print(f"  [缺失] {pkg:<16} 必需 — {exc}")
        fail += 1
for mod, pkg in OPTIONAL_PKGS:
    try:
        m = importlib.import_module(mod)
        ver = getattr(m, "__version__", "")
        print(f"  [OK]   {pkg:<16} {ver}（可选）")
    except Exception:
        print(f"  [跳过] {pkg:<16} 可选，未安装")

section("3. 硬编码路径提示")
for rel in EXPECTED:
    p = ROOT / rel
    if not p.is_file() or p.suffix not in (".py", ".md"):
        continue
    try:
        text = p.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        continue
    for i, line in enumerate(text.splitlines(), 1):
        if "C:\\Users\\Andre Fan" in line or "D:/shared/templates" in line:
            print(f"  {rel}:{i}  {line.strip()[:100]}")
print("  说明：以上路径需按 README 第四节调整后方可跨机器使用。")

section("4. 模块导入与接口")
sys.path.insert(0, str(SKILLS))
sys.path.insert(0, str(SKILLS / "docx-secure-renderer"))

try:
    from writer import TechnicalProposalWriter  # noqa: F401
    print("  [OK]   writer.TechnicalProposalWriter")
except Exception as exc:
    print(f"  [失败] writer.TechnicalProposalWriter — {exc}")
    fail += 1

try:
    import omml_helper
    for fn in ("add_omath_paragraph", "add_inline_math_paragraph", "parse_formula"):
        getattr(omml_helper, fn)
        print(f"  [OK]   omml_helper.{fn}")
except Exception as exc:
    print(f"  [失败] omml_helper — {exc}")
    fail += 1

try:
    import renderer
    print("  [OK]   renderer.validate_docx" if hasattr(renderer, "validate_docx")
          else "  [警告] renderer 已导入但无 validate_docx")
except Exception as exc:
    print(f"  [失败] renderer — {exc}")
    fail += 1

try:
    sys.path.insert(0, str(SKILLS / "patent-writer"))
    import formula_parser
    fn = getattr(formula_parser, "parse_formula_enhanced", None)
    print(f"  [OK]   formula_parser.parse_formula_enhanced {'可用' if fn else '不存在'}")
except Exception as exc:
    print(f"  [跳过] formula_parser — {exc}（将回退到基础解析器）")

section("结论")
if fail:
    print(f"  自检发现 {fail} 项必需项缺失，请按上方提示处理。")
    sys.exit(1)
print("  必需项全部通过。可选依赖缺失不影响核心写作链路（会降级）。")
